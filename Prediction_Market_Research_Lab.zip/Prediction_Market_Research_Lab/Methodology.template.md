# Technical methodology

Research date: October 14, 2026. This is an offline historical study and a separate synthetic null experiment. There are no order submission functions, authenticated platform clients, wallet discovery lists, live odds, or account connections in the supplied analytical pipeline.

## Research question and estimands

The target question is whether a participant’s past profitability predicts later performance and whether a hypothetical follower could obtain an advantage after costs. Neither estimand is identifiable from the acquired archive: there are no participant histories. The supported estimands are (1) market-reference forecast scores against provider-reported outcomes, (2) conditional one-share cashflows at archived asks, (3) paired changes in quote-based entry costs after delayed observation, and (4) selection-induced performance in a known zero-skill synthetic population. Do not substitute these for observed copying performance.

## Source, coverage and reliability

The source is Marketlens’s public Polymarket Historical Data archive, pinned to Git commit `6eb9b8efda545eddafb2a8f75acb4bcbca6db019`, released under CC BY 4.0. Original source: https://github.com/marketlenstrade/polymarket-historical-data. Attribution: Marketlens, https://marketlens.trade. The provider’s manifest records 2,278 markets, 17,317,874 book/trade event rows, and seven selected chapters. All 2,278 history-file SHA-256 hashes and row counts match the manifest. This establishes integrity relative to that manifest, not authenticity relative to the exchange. The data were retrieved over verified HTTPS; no TLS or checksum verification was disabled.

The analyzed record window runs June 5–September 10, 2026 UTC. These are selected event windows, not continuous coverage of every platform market. Source-reported outcomes are not independently corroborated with official settlements: network policy blocked the official APIs. In particular, a good Brier score is conditional on the supplied labels being correct. Historical_Data.csv is labeled `third_party_reported_historical`; no synthetic participants are placed in that file.

Kalshi’s official community notebooks and the Becker collector schemas were inspected, but no usable Kalshi historical dataset was acquired. Do not interpret the lab as a numerical cross-platform comparison.

## Raw validation and exclusions

`src/prepare_data.py` validates file hashes and row counts, original event timestamp ordering, all 1,120,033 trade prices/sizes and trade-ID uniqueness, snapshot JSON levels, quote bounds, nonnegative depth, and settlement-label membership in two unique outcome names. Timestamps are interpreted in UTC with millisecond precision; the provider’s CSV human-readable times can round seconds, so numerical Parquet timestamps take precedence.

The audit found zero duplicate or missing trade IDs, invalid trade price/size rows, or unsorted raw event tapes. In the snapshot audit for retained metadata/cadences, 249,530 of 611,090 stored snapshot rows have empty or invalid two-sided books; 4,897 are at/after the earlier of the reported close and resolution time. Categories can overlap in these row counts. Empty books are observations about unavailable quotes, not evidence of a fill at zero cost. Conflicting simultaneous snapshots are rejected; exact duplicates are removed. In this run both counts were zero.

The market-level exclusions are 120 longer-cadence crypto contracts whose windows overlap the five-minute sample, 108 markets without a valid preclose two-sided snapshot, and 29 markets with nonbinary/ambiguous settlement labels. The latter are provider-encoded half/half payouts, not binary losses; they were excluded rather than assigned zero. There are 2,021 retained markets and 171 event clusters. Full reasons and affected provider market IDs are in Excluded_Observations.csv. Filtering settled, quote-observable markets can itself cause selection bias; excluded markets are never presumed unprofitable or profitable.

## Outcome normalization and timing

Each market’s first named outcome is the reference outcome. `y=1` exactly when the provider winner equals that name; `y=0` when the other outcome wins. First-outcome names can be Yes, Up, Over, a team, or a named athlete. The reference market probability is the midpoint of the first valid archived two-sided book before both close and resolution. It is neither a participant’s subjective forecast nor an executable price. The first captured book can be well after market creation and can be in-play; forecast horizons are heterogeneous. Volume and future settlement prices are not model inputs or sample-ranking criteria.

## Event clustering and time separation

All contracts within the provider’s named sports/weather/equity event are grouped. Five-minute crypto contracts are grouped by UTC hour, acknowledging dependence between consecutive windows. Fifteen-minute and hourly crypto contracts are excluded. Event groups are ordered by their earliest forecast time, then assigned 60% training, 20% validation and 20% test by group count. Any earlier-period group whose latest settlement is not strictly before the next period’s earliest forecast is purged. This prevents using outcomes that would not yet have been known and prevents correlated contracts from spanning periods.

The resulting periods contain 1,765 training markets/97 groups, 83 validation markets/13 groups, and 93 test markets/35 groups. Five training groups (7 markets) and 21 validation groups (73 markets) are purged. A count split by groups is not a 60/20/20 split by markets or calendar duration. The final test is entirely esports on September 10, 2026; the unpurged training period has no esports. Thus temporal separation is valid, while broad cross-category transfer and population generalization are unsupported. Minimum prior category-support checks correctly return zero test observations, not a passing result.

## Forecast models and holdout

The prespecified candidates are `p_adjusted=(1-a)*p_market+a*0.5`, for `a` in {0, 0.25, 0.5}. The candidate with lowest validation Brier is frozen; ties favor zero shrinkage. Benchmarks are the archived market midpoint, constant 0.5, and the empirical event rate calculated using training outcomes only. Development writes Selected_Model.json with design/data SHA-256 hashes before final evaluation. First_Test_Evaluation.json records the initial evaluation. Unit tests reverse every test outcome and confirm development selection is unchanged. After that initial evaluation, robustness and dashboard reruns are exploratory; they do not create new untouched tests.

The selected candidate has `a=0.5`. It is a simple probability regularization diagnostic, not a fitted trader model or an optimized wagering system. Model selection was not repeated after seeing primary test results. The code may be rerun to reproduce calculations, but the original test remains the original holdout.

## Scores and uncertainty

For one binary market: `Brier=(p-y)^2`; `log_loss=-(y*log(p)+(1-y)*log(1-p))`. Log-loss inputs are clipped to [1e-6,1-1e-6] only to avoid undefined logarithms. Accuracy treats p>=0.5 as a prediction of the first outcome, including ties. Brier/log loss measure probabilistic forecasts; accuracy is secondary and does not imply profitability. Calibration uses ten fixed probability bins with mean quoted midpoint against mean outcome. No bin with zero observations is plotted as a zero-frequency observation.

Primary 95% intervals resample complete event clusters 2,000 times with replacement, preserving all contracts in each selected group; market-weighted means use resampled sums divided by resampled observation counts. Paired Brier comparisons resample per-market loss differences within the same groups. There is no interval with fewer than two clusters. Sparse category intervals, especially one equity event or three weather events, cannot support reliable comparative inference. These are conditional intervals for this provider-selected sample, not probability-sample estimates for all traders.

Exploratory two-sided sign-flip p-values use 10,000 random signs on event-group loss sums, requiring exchangeable/symmetric independent group errors. Holm adjustment covers the three prespecified test Brier comparisons only. Cross-event common shocks, many unreported researcher choices, and the single-day test weaken that assumption; thresholds are not a proof of platform-wide forecasting efficiency. Whole-chapter bootstrap is an additional exploratory dependence sensitivity. Six chapters contribute eligible paper positions; the seven source chapters remain a very small set of provider-selected blocks.

## Conditional historical paper benchmark

The benchmark is deliberately simple: model one share of the first named outcome at an eligible recorded ask and hold to the reported settlement. It is a mechanical reference experiment, not copying a participant. Eligibility requires a two-sided noncrossed book, best-ask size at least one share, price strictly between zero and one, spread <=0.20, and a quote before both close and resolution. Full Parquet snapshot depth is used; aggregate depth from the summary CSV is not confused with available quantity at the best ask. All failed eligibility observations and reasons remain in Paper_Skips.csv.

For quantity q, ask a, payout y, and hypothetical additional cost c per share: `gross_pnl=q*(y-a)`, `modeled_cost=q*c`, `net_pnl=q*y-q*a-q*c`, and `outlay=q*(a+c)`. These identities are tested independently. Prices already include spread crossing; the cost c is additional. A one-cent per-share scenario is the primary sensitivity setting, with zero, 0.005, 0.01, 0.02 and 0.05 also reported. These are explicitly hypothetical all-in additional costs, not verified historical Polymarket or Kalshi fee schedules. Zero additional cost is an optimistic scenario, not an assertion of fee-free trading. No fee rate, rebate, gas allocation, or effective-date change was recovered sufficiently to reconstruct actual net trader profits.

Recorded depth is necessary but insufficient evidence for a historical fill. Quote disappearance, matching priority, minimum order size, network timing, cross-asset routing, and impact are unknown. The one-share model is consequently a conditional quote-taking accounting experiment; it is not a realizable executable backtest. A minimum-dollar-order constraint could invalidate additional modeled positions. No passive queue fills are assumed. No inverse-outcome price is fabricated from a complement. There is no strategy signal, target wallet, order size recommendation, or live endpoint in the simulation.

Aggregate return is total modeled net P&L divided by summed modeled outlay. It is labeled `return_on_aggregate_outlay`, not ROI on a participant’s capital. Summing successive outlays does not measure capital tied up over time. Reported cumulative curves order finalized position P&L by settlement time. The maximum decline in that cumulative settled P&L is not maximum portfolio equity drawdown: open-position marks, financing, and collateral paths are absent. Deposits, withdrawals, actual realized trader P&L, and unrealized participant P&L are unsupported.

## Observation-delay experiment

Requested delays are 0, 30, 60, 300, and 900 seconds from the reference book. Entry is modeled at the first valid full snapshot at/after the delayed target, with at most 300 seconds of additional wait. Both effective delay and extra snapshot wait are recorded. The archive’s compacted level changes are not treated as exact executable books at arbitrary intermediate instants. Provider snapshots are sparse; a requested 30-second delay does not mean an observed quote exactly 30 seconds later. Trades without an eligible later snapshot are skipped, never filled at an earlier favorable price.

Two views are reported: full delayed cohorts, which differ in coverage, and matched comparisons containing only markets eligible at both anchor and delayed times. For matched one-share positions with the same settlement and fixed extra cost, the delayed-minus-anchor P&L difference is exactly the negative change in ask. Its clustered interval describes the matched selected cohort, not an average causal treatment effect for all markets or actual follower performance. Delay can worsen or improve a quote; no monotone deterioration is imposed.

## Synthetic selection-bias experiment

Each of 250 independent simulations generates 1,000 unskilled hypothetical participants and 200 fair Bernoulli trials per participant. The probability of success is known to be exactly 0.5 for everyone. The first 120 trials are training, next 40 validation, final 40 test. Select the top 50 (5%) by training win rate only, with deterministic participant-order tie breaking. Compare their subsequent win rate with the population and with a deliberately forbidden oracle that selects using test results. Synthetic P&L per trial is outcome minus 0.5, with no fees; it is not denominated platform earnings. All synthetic IDs have a `SYN` prefix.

Reported simulation percentiles describe between-world variation; Monte Carlo standard errors describe precision of the average across simulated worlds. Neither is a confidence interval for real traders. Alternative training fractions 0.4, 0.5, 0.6, 0.7 and minimum observation requirements 20, 80, 130 are recorded. Insufficient scenarios are flagged. Dashboard changes rerun one representative seeded synthetic world locally; those interactive values are illustrative single-world results and need not equal the 250-world aggregate.

## Robustness, missing evidence and supported scope

Outputs include alternative group-time splits, lower/higher spread gates, removal of the largest positive paper contributions, exclusion of extreme reference probabilities, category tables, cost/delay grids, matched-delay intervals, whole-chapter dependence sensitivity, and minimum prior category support. All post-primary split comparisons are exploratory. Full-sample descriptive outcomes include purged markets; purging excludes them from training/model evaluation, not from transparent descriptive accounting. No threshold is changed to rescue a losing primary result.

Experiments A (actual participant persistence) and B (participant information beyond price) are unsupported. C is supported only as a synthetic mathematical demonstration. D and F are supported as conditional archived-quote experiments with hypothetical extra costs. E is descriptive only, with one selected chapter per category and no politics sample. Observed profit distributions, percentage of profitable users, profit concentration, actual copying returns, trader ROI, and Kalshi comparative performance remain unmeasured.

## Reproduction and files

Use Python 3.12 and the hash-pinned `requirements.lock`. From the lab root run `python src/analysis.py develop`, then `python src/analysis.py evaluate`, then `python -m pytest tests`. This requires only the supplied CSV files and design, without network or any account. The recorded original-holdout metadata should be retained; rerunning development/evaluation is reproduction, not a fresh confirmatory experiment.

To repeat raw validation, `python src/download_archive.py` optionally downloads the pinned public GitHub archive; `python src/prepare_data.py` then verifies it. This optional acquisition is separate from the fully offline workflow. It needs roughly 400 MB for compressed/extracted source data. `src/build_deliverables.py` builds charts, HTML, XLSX, documentation and the notebook; PDF printing and browser smoke tests use an installed Chromium via Playwright. Data_Dictionary.md describes every column of the two principal historical CSVs and the paper-accounting output. Sources.md and Source_Manifest.json record inspected sources, blocked requests, dates and content hashes. Research_Report.md is the editable PDF report source.
