import json
from pathlib import Path
import sys
import numpy as np
import pandas as pd
import pytest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
import analysis

def test_metric_known_values_and_invalid_probabilities():
    v=analysis.metric_values([1,0],[.25,.75])
    assert np.allclose(v['brier'],[.5625,.5625])
    assert np.allclose(v['log_loss'],[np.log(4),np.log(4)])
    assert np.all(v['accuracy']==0)
    with pytest.raises(ValueError):analysis.metric_values([1],[1.1])
    with pytest.raises(ValueError):analysis.metric_values([.5],[.5])

def test_real_data_unique_chronological_and_settled():
    d=analysis.read_data()
    assert len(d)==2021
    assert not d.market_id.duplicated().any()
    assert d.anchor_time.is_monotonic_increasing
    assert (d.anchor_time<d.resolved_at).all()
    assert (d.anchor_time<d.close_time).all()
    assert d.p_market.between(0,1,inclusive='neither').all()
    assert set(d.y)=={0,1}
    assert d.winning_outcome.isin(pd.concat([d.outcome_name,d.other_outcome_name]).unique()).all()
    assert (d.y==(d.winning_outcome==d.outcome_name).astype(int)).all()
    assert set(d.data_kind)=={'third_party_reported_historical'}

def test_event_and_label_availability_separation():
    d=analysis.assign_splits(analysis.read_data())
    for a,b in [('train','validation'),('validation','test'),('train','test')]:
        x=d[d.split==a];y=d[d.split==b]
        assert set(x.event_cluster).isdisjoint(y.event_cluster)
        assert x.resolved_at.max()<y.anchor_time.min()
    assert len(d[d.split=='test'])==93
    assert d[d.split=='test'].category.unique().tolist()==['Esports']

def test_test_labels_cannot_change_development_selection(tmp_path,monkeypatch):
    before=json.loads((analysis.OUT/'Selected_Model.json').read_text())
    d=analysis.assign_splits(analysis.read_data())
    d.loc[d.split=='test','y']=1-d.loc[d.split=='test','y']
    (tmp_path/'Historical_Data.csv').write_bytes((analysis.OUT/'Historical_Data.csv').read_bytes())
    monkeypatch.setattr(analysis,'OUT',tmp_path)
    monkeypatch.setattr(analysis,'read_data',lambda:d.copy())
    analysis.develop()
    after=json.loads((tmp_path/'Selected_Model.json').read_text())
    assert before['shrinkage']==after['shrinkage']
    assert before['candidates']==after['candidates']
    assert before['training_event_rate']==after['training_event_rate']

def test_paper_cashflow_reconciliation_and_losses():
    d=pd.read_csv(analysis.OUT/'Paper_Positions.csv')
    expected=d.quantity*d.y-d.quantity*d.ask-d.modeled_cost
    assert np.allclose(expected,d.net_pnl,atol=1e-12)
    assert np.allclose(d.gross_pnl,d.quantity*(d.y-d.ask))
    assert np.allclose(d.outlay,d.quantity*d.ask+d.modeled_cost)
    assert (d.net_pnl<0).any() and (d.net_pnl>0).any()
    assert np.isclose(d.net_pnl.sum(),-62.6495)
    assert np.all(d.ask_size>=d.quantity)
    assert np.all(d.spread<=.2)

def test_invalid_liquidity_is_not_treated_as_a_fill():
    q=pd.read_csv(analysis.OUT/'Historical_Execution_Quotes.csv').head(5).copy()
    q.loc[q.requested_delay_seconds==0,'ask_size']=.5
    rows,skip=analysis.simulate(q)
    assert len(rows)==0
    assert 'insufficient_best_ask_depth' in set(skip.skip_reason)

def test_quote_delays_and_no_postsettlement_execution():
    q=pd.read_csv(analysis.OUT/'Historical_Execution_Quotes.csv')
    good=q[q.execution_status=='eligible']
    anchor=pd.to_datetime(good.anchor_time,utc=True,format='ISO8601')
    quote=pd.to_datetime(good.quote_time,utc=True,format='ISO8601')
    final=pd.to_datetime(good.resolved_at,utc=True,format='ISO8601')
    assert (quote>=anchor+pd.to_timedelta(good.requested_delay_seconds,unit='s')).all()
    assert (quote<final).all()
    assert good.additional_snapshot_wait_seconds.between(0,300).all()
    assert not q.duplicated(['market_id','requested_delay_seconds']).any()

def test_audit_and_exclusions_reconcile():
    o=analysis.OUT
    s=json.loads((o/'Data_Summary.json').read_text())
    a=pd.read_csv(o/'Data_Audit.csv');e=pd.read_csv(o/'Excluded_Observations.csv')
    assert a.market_id.nunique()==2278
    assert len(e)+s['retained_markets']==2278
    assert a.raw_rows.sum()==17317874
    assert a.trade_rows.sum()==1120033
    assert not (a[['duplicate_trade_ids','invalid_trade_rows','missing_trade_ids']].fillna(0).to_numpy()>0).any()

def test_cluster_bootstrap_counts_events_not_contracts():
    d=pd.DataFrame({'event_cluster':['a']*100+['b']})
    ci=analysis.cluster_interval(d,np.r_[np.zeros(100),1.])
    assert ci['clusters']==2
    assert np.isclose(ci['estimate'],1/101)
    assert ci['ci_high']>.9

def test_synthetic_null_not_observed_platform_performance():
    s=json.loads((analysis.OUT/'Synthetic_Selection_Summary.json').read_text())
    assert s['data_kind']=='SYNTHETIC_NULL_ONLY'
    assert s['true_skill']==0
    assert s['summaries']['selected_train_win_rate']['mean']>.58
    assert abs(s['summaries']['selected_test_win_rate']['mean']-.5)<.005
    assert s['summaries']['forbidden_test_selected_win_rate']['mean']>.64

def test_data_contains_no_wallet_identifiers():
    text=(analysis.OUT/'Historical_Data.csv').read_text()
    import re
    assert re.search(r'0x[a-fA-F0-9]{40}',text) is None
    assert not any(c in analysis.read_data().columns for c in ['maker','taker','wallet','address','private_key'])
