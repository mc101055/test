# Sources and access audit

Research date: October 14, 2026. All access dates below are 2026-10-14. Source content was retrieved by HTTPS using local research tools. No general browser/search connector was available; public GitHub search pages and raw files were inspected. The proxy blocked the destinations listed below. No Reddit thread, academic full text, official API settlement response, or current fee schedule is represented as inspected. Text hashes identify the inspected cache after redacting public wallet/address examples; they are not claims of an unmodified upstream response. Source dataset Parquet hashes are checked separately against the original provider manifest.

## Inspected sources

### [S01] Marketlens historical archive README
- URL: https://raw.githubusercontent.com/marketlenstrade/polymarket-historical-data/6eb9b8efda545eddafb2a8f75acb4bcbca6db019/README.md
- Type: Third-party dataset provider
- Use and limit: Coverage and collection claims; no independent exchange verification.
- Inspected cached-text SHA-256: `1e6f3446b01970cd3d2aaca7cb02ed657551235c263f79f8c270721cf3028745`

### [S02] Marketlens archive manifest
- URL: https://raw.githubusercontent.com/marketlenstrade/polymarket-historical-data/6eb9b8efda545eddafb2a8f75acb4bcbca6db019/manifest.json
- Type: Third-party dataset manifest
- Use and limit: Exact file hashes, reported counts and date windows; all history hashes checked.
- Inspected cached-text SHA-256: `981ddf2544d2e781bfe8b1dc7eda933f5d337b9ff882134e138e0cacb8ed2377`

### [S03] Marketlens collection/export source
- URL: https://raw.githubusercontent.com/marketlenstrade/polymarket-historical-data/6eb9b8efda545eddafb2a8f75acb4bcbca6db019/tools/build.py
- Type: Third-party collection code
- Use and limit: Resolved-only sample selection, book export, snapshot subsampling and settlement metadata provenance.
- Inspected cached-text SHA-256: `3679ff49e874e418a5bc3a1cb1cfeb2e988393c64e205f7150912b21ce900acb`

### [S04] Marketlens data license
- URL: https://raw.githubusercontent.com/marketlenstrade/polymarket-historical-data/6eb9b8efda545eddafb2a8f75acb4bcbca6db019/LICENSE
- Type: Dataset license
- Use and limit: CC BY 4.0; attribution: Marketlens, https://marketlens.trade.
- Inspected cached-text SHA-256: `9ba9550ad48438d0836ddab3da480b3b69ffa0aac7b7878b5a0039e7ab429411`

### [S05] Marketlens citation metadata
- URL: https://raw.githubusercontent.com/marketlenstrade/polymarket-historical-data/6eb9b8efda545eddafb2a8f75acb4bcbca6db019/CITATION.cff
- Type: Dataset citation metadata
- Use and limit: Dataset author and citation details.
- Inspected cached-text SHA-256: `1235b438135833a592dbecc996ee1bdbfd1af56ba59a52c453e301ef538803dc`

### [S06] Historical Polymarket CTF exchange overview
- URL: https://raw.githubusercontent.com/Polymarket/ctf-exchange/main/docs/Overview.md
- Type: Primary platform technical source, archived
- Use and limit: Off-chain matching and on-chain settlement; mint/merge mechanics; signed fee terms. Not a dated platform-wide fee schedule.
- Inspected cached-text SHA-256: `f70d93b5dbcfa2c7aa7276bece090ba4e167c71fd0ad469fe83a85157b1dcc1e`

### [S07] Archived Polymarket CLOB client README
- URL: https://raw.githubusercontent.com/Polymarket/py-clob-client/main/README.md
- Type: Primary platform technical source, archived
- Use and limit: Read-only market interfaces versus authenticated functions; explicit warning that this SDK is no longer functional.
- Inspected cached-text SHA-256: `a219827ad13a1ab48ef2a8366a4702ee7411e4dff52aa2800a76ab5529bd74c2`

### [S08] Current Polymarket Python SDK README
- URL: https://raw.githubusercontent.com/Polymarket/py-sdk/main/README.md
- Type: Primary platform technical source
- Use and limit: Migration destination, evolving API surface. Not installed or used to trade.
- Inspected cached-text SHA-256: `ad3fde3677d0b2abd368fed7148efbfa560c57d74c3b1f98d22e94e1658d7b51`

### [S09] Kalshi official Python starter README
- URL: https://raw.githubusercontent.com/Kalshi/kalshi-starter-code-python/main/README.md
- Type: Primary platform technical source
- Use and limit: Example for authenticated endpoints; not evidence of public account ledgers.
- Inspected cached-text SHA-256: `0b2b0642e1b4427262b136a1e3ded8c683a63cd7a06667ec35cf97ea084baecb`

### [S10] Kalshi official starter client source
- URL: https://raw.githubusercontent.com/Kalshi/kalshi-starter-code-python/main/clients.py
- Type: Primary platform client code
- Use and limit: Signed authentication and portfolio/market routes. Client code alone does not establish all public endpoint permissions.
- Inspected cached-text SHA-256: `de35344af496cb26690af83dcb84defb9cd762392308ca6e3b42275f46306a18`

### [S11] Kalshi community analysis repository README
- URL: https://raw.githubusercontent.com/Kalshi/tools-and-analysis/main/README.md
- Type: Officially hosted community work
- Use and limit: Forecast visualization examples; notebooks depend on authenticated historical retrieval, not a shipped transaction dataset.
- Inspected cached-text SHA-256: `c2a3206b863b9a820177c5f2869d54aa358c87eb9ccf817a9ff20e1de65f4eaa`

### [S12] Becker research framework README
- URL: https://raw.githubusercontent.com/Jon-Becker/prediction-market-analysis/main/README.md
- Type: Independent research repository
- Use and limit: Documents 36 GiB compressed external archive and a bibliography. Largest-dataset claim not independently verified.
- Inspected cached-text SHA-256: `9596ded62210245b634814f9c99bf0560d05635ea0610cc8e78687da5bda9d71`

### [S13] Becker market/trade schemas
- URL: https://raw.githubusercontent.com/Jon-Becker/prediction-market-analysis/main/docs/SCHEMAS.md
- Type: Independent collector documentation
- Use and limit: Kalshi tape lacks participant IDs; Polymarket fills expose on-chain roles and amounts but require token/time/redemption joins.
- Inspected cached-text SHA-256: `6d85ad5d296adcd3bec2ad57fb2fe030e095b85fd1f865b2e15e619121458b15`

### [S14] Becker Kalshi maker/taker analysis code
- URL: https://raw.githubusercontent.com/Jon-Becker/prediction-market-analysis/9afe7a1cb8fd5acb207fb01027d6114a414f0cd2/src/analysis/kalshi/maker_vs_taker_returns.py
- Type: Independent analytical code
- Use and limit: Role-level settlement-P&L construction; role aggregates are not individual participant persistence.
- Inspected cached-text SHA-256: `ce58c094c153d597c64dbf9020ee523eec5a1337e2062f58feb0f1e78556f8c8`

### [S15] Becker Polymarket calibration code
- URL: https://raw.githubusercontent.com/Jon-Becker/prediction-market-analysis/9afe7a1cb8fd5acb207fb01027d6114a414f0cd2/src/analysis/polymarket/polymarket_calibration_by_bucket.py
- Type: Independent analytical code
- Use and limit: Trade-weighted calibration and bucket-approximate Brier; repeated-event dependence remains a research design issue.
- Inspected cached-text SHA-256: `4ec1c96624d8ef0860383eb8477d2545cf4a4689195f74c71a5e0ec45ea9002e`

### [S16] Becker statistical analysis code
- URL: https://raw.githubusercontent.com/Jon-Becker/prediction-market-analysis/9afe7a1cb8fd5acb207fb01027d6114a414f0cd2/src/analysis/kalshi/statistical_tests.py
- Type: Independent analytical code
- Use and limit: Some comparisons count contracts in proportions; audit independence and multiplicity before interpreting significance. Not rerun without data.
- Inspected cached-text SHA-256: `224a9291ed11ce168b112262504834f113a980d7fa776085bd386faf77ff2e90`

### [S17] Open-source copying project README
- URL: https://raw.githubusercontent.com/shmlkv/polymarket-copy-trading-bot/main/README.md
- Type: Promotional/self-authored project description
- Use and limit: Claims of copying best traders and immediate execution; dashboard images do not supply an audited follower ledger.
- Inspected cached-text SHA-256: `2cc17b0104df96b32d1235574a64e838814a4461d2ce11c8500274f650ecf3cd`

### [S18] Prediction-market toolkits README
- URL: https://raw.githubusercontent.com/HarrierOnChain/Prediction-Markets-Trading-Bot-Toolkits/main/README.md
- Type: Promotional/self-authored project description
- Use and limit: Explicitly describes hosted copying beta as paper trading, closed, and never touching real funds. Not verified earned profits.
- Inspected cached-text SHA-256: `e89ab1077dc25754ddb31b48ce1c4ac68dc91722c2707eb068769f7e4f8d2927`

### [S19] Polymarket copy-research README
- URL: https://raw.githubusercontent.com/artym359/polymarket-copy-research/main/README.md
- Type: Independent methodological repository
- Use and limit: Documents lifecycle sizing, proxy prices, look-ahead hazards, missing equity curves, and missing public raw histories. No independently reproducible success proof.
- Inspected cached-text SHA-256: `e988e9da79410b4016eed1ceae4aad7ff6a18aa3e0cbd72d2f806f89f4cf5c7e`

### [S20] Polymarket historical price collector README
- URL: https://raw.githubusercontent.com/LuciferForge/polymarket-historical-data/main/README.md
- Type: Dataset vendor/self-report
- Use and limit: Admits no resolution labels and mostly placeholder order books; claims live results but no independent audit completed here.
- Inspected cached-text SHA-256: `178aecd6e2003d2335da166aa7acae06e0eea59f9f45df5770a804d9712965cb`

### [S21] Earlier historical price-sample README
- URL: https://raw.githubusercontent.com/manja316/polymarket-historical-data/main/README.md
- Type: Dataset vendor/self-report
- Use and limit: Advertises price snapshots, backtest results and paid complete data. Distinguish previews, modeled results and realized execution.
- Inspected cached-text SHA-256: `d692fd73333ce3231537bfd9155ed269e0557203584ec4b554d75626cf6271e5`

### [S22] Crash-recovery project README
- URL: https://raw.githubusercontent.com/LuciferForge/polymarket-crash-bot/main/README.md
- Type: Self-reported strategy results, not copying
- Use and limit: 280 trades, 80.4% claimed win rate in this README; related README claims 302/79.8%. Different snapshots/definitions cannot be reconciled from summaries.
- Inspected cached-text SHA-256: `24e5e6a6f66dc0a8ac832c8bb9d25f34291e2a8e635354a0737a46c0e74a5983`

### [S23] GitHub repository search: copying
- URL: https://github.com/search?q=polymarket+copy+trading&type=repositories
- Type: Search result, not performance evidence
- Use and limit: Discovery only. Search rankings and star counts do not verify profitability.
- Inspected cached-text SHA-256: `071b2ece44d1cb7af631c89fdae85c715a71e9df9144b59a803043ba40cab184`

### [S24] GitHub repository search: historical data
- URL: https://github.com/search?q=polymarket+historical+data&type=repositories
- Type: Search result, not dataset validation
- Use and limit: Discovery of archives, collectors and vendor samples.
- Inspected cached-text SHA-256: `87cceb004c744e4065a0dde4ff0e9a02a9d496f1e6eb4d05d0e718658ddb0aef`

### [S25] Archived Polymarket CTF exchange README
- URL: https://raw.githubusercontent.com/Polymarket/ctf-exchange/main/README.md
- Type: Primary platform technical source, archived
- Use and limit: Explicit archive warning and V2 replacement destination; not a verified historical fee schedule.
- Inspected cached-text SHA-256: `524e4fa28893c041397cbe1a1ef43625fb48c912b3a5fbe024e6f96b2ac7ad2d`

### [S26] Becker framework software license
- URL: https://raw.githubusercontent.com/Jon-Becker/prediction-market-analysis/main/LICENSE
- Type: Software license
- Use and limit: MIT software license; do not infer independent data redistribution rights.
- Inspected cached-text SHA-256: `a69ab694cc5a08793bc36673976a4bd97ef37a26786cd94a14072268550338f5`

### [S27] Kalshi community Oscars notebook
- URL: https://raw.githubusercontent.com/Kalshi/tools-and-analysis/main/projects/oscars_2023/main.ipynb
- Type: Officially hosted community notebook
- Use and limit: Inspected code/outputs; uses authenticated historical calls, not a shipped participant panel.
- Inspected cached-text SHA-256: `94c215781dea4b6a3e10ce61bedde57b3efe403da05b4e4d1544a639fcb3d4e0`

### [S28] Kalshi community rate-market notebook
- URL: https://raw.githubusercontent.com/Kalshi/tools-and-analysis/main/projects/fed_feb_2023/main.ipynb
- Type: Officially hosted community notebook
- Use and limit: Inspected code/outputs; no recovered raw historical market or participant ledger.
- Inspected cached-text SHA-256: `3766d41560ac2b882008fda9c40aab35ba1c58cc8737762298fc7dc629f11ba9`

## Blocked requests (not read)

- [N01] Polymarket documentation: https://docs.polymarket.com/llms.txt — proxy CONNECT 403 Forbidden.
- [N02] Kalshi documentation: https://docs.kalshi.com/llms.txt — proxy CONNECT 403 Forbidden.
- [N03] GitHub REST metadata: https://api.github.com/repos/Jon-Becker/prediction-market-analysis — proxy CONNECT 403 Forbidden.
- [N04] Academic search: https://arxiv.org/search/?query=polymarket&searchtype=all — proxy CONNECT 403 Forbidden.
- [N05] Reddit copying discussion search: https://www.reddit.com/search.json?q=polymarket%20copy%20trading&limit=10 — proxy CONNECT 403 Forbidden.
- [N06] Polymarket settled market metadata: https://gamma-api.polymarket.com/markets?limit=2&closed=true&end_date_max=2025-01-01T00%3A00%3A00Z — proxy CONNECT 403 Forbidden.
- [N07] Kalshi settled markets: https://api.elections.kalshi.com/trade-api/v2/markets?limit=2&status=settled — proxy CONNECT 403 Forbidden.
- [N08] Broad web search: https://www.google.com/search?q=polymarket+copy+trading+profit+research — proxy CONNECT 403 Forbidden.

## Additional discovered literature — bibliographic leads only

The following titles and links appeared in the inspected Becker README [S12]. Full papers, authorship details, revisions, peer-review status and numerical findings were not independently verified. They are leads for completing the blocked literature review, not support for this report’s findings.

- Reichenbach and Walther, *Exploring Decentralized Prediction Markets: Accuracy, Skill, and Bias on Polymarket* (listed as 2025): https://papers.ssrn.com/sol3/papers.cfm?abstract_id=5910522
- Akey et al., *Who Wins and Who Loses In Prediction Markets? Evidence from Polymarket* (listed as 2026): https://papers.ssrn.com/sol3/papers.cfm?abstract_id=6443103
- Luong and Heesen, *The Wisdom of the Few: Skilled Traders and Prediction Market Accuracy* (listed as 2026): https://papers.ssrn.com/sol3/papers.cfm?abstract_id=6758662
- Bartlett and O’Hara, *Adverse Selection in Prediction Markets: Evidence from Kalshi* (listed as 2026): https://papers.ssrn.com/sol3/papers.cfm?abstract_id=6615739
- Cardozo and Rivero-Wildemauwe, *The Favorite-Longshot Bias in Prediction Markets: Evidence from Polymarket* (listed as 2026): https://arxiv.org/abs/2609.12878

## Data attribution and redistribution

Historical records are derived from Marketlens, https://marketlens.trade, *Polymarket Historical Data*, pinned Git commit `6eb9b8efda545eddafb2a8f75acb4bcbca6db019`. Original source: https://github.com/marketlenstrade/polymarket-historical-data. The provider releases data under CC BY 4.0 [S04]; license text is included as `Data_License.txt`. Changes: selected binary settled markets, excluded overlapping crypto cadences and unusable records, normalized first-outcome labels, extracted top quote sizes, grouped related events, and computed offline metrics. No platform endorsement is implied.

The Becker framework is MIT-licensed, but its external data archive was not downloaded or redistributed. Do not infer all platform data rights from a software license. Other vendor price samples were assessed from documentation only and are not redistributed.

## Network configuration saved

A draft adds docs.polymarket.com, docs.kalshi.com, gamma-api.polymarket.com, clob.polymarket.com, api.elections.kalshi.com, api.github.com, arxiv.org, export.arxiv.org, www.reddit.com, www.google.com, s3.jbecker.dev, and papers.ssrn.com. Package-manager presets were preserved. Draft save was confirmed; these additions were not applied to or tested in a newly published environment. To extend the blocked research, review and save settings, then publish the environment and recheck access. No account keys are needed for the supplied offline lab.

## Additional discovery requests

These queries supplement the 28 cataloged source entries. A zero-result query does not establish that relevant data or research does not exist. All were accessed on 2026-10-14; no contributor identities or candidate wallets are published.

- org:Polymarket docs (repositories): https://github.com/search?q=org%3APolymarket+docs&type=repositories — GitHub-reported results: 0.
- org:Kalshi docs (repositories): https://github.com/search?q=org%3AKalshi+docs&type=repositories — GitHub-reported results: 0.
- kalshi historical dataset (repositories): https://github.com/search?q=kalshi+historical+dataset&type=repositories — GitHub-reported results: 0.
- polymarket calibration skill (repositories): https://github.com/search?q=polymarket+calibration+skill&type=repositories — GitHub-reported results: 3.
- org:Kalshi (repositories): https://github.com/search?q=org%3AKalshi&type=repositories — GitHub-reported results: 3.
- polymarket paper arbitrage (repositories): https://github.com/search?q=polymarket+paper+arbitrage&type=repositories — GitHub-reported results: 61.
- prediction markets trader skill research (repositories): https://github.com/search?q=prediction+markets+trader+skill+research&type=repositories — GitHub-reported results: 0.
- repo:shmlkv/polymarket-copy-trading-bot loss (issues): https://github.com/search?q=repo%3Ashmlkv%2Fpolymarket-copy-trading-bot+loss&type=issues — GitHub-reported results: 0.
- repo:HarrierOnChain/Prediction-Markets-Trading-Bot-Toolkits loss (issues): https://github.com/search?q=repo%3AHarrierOnChain%2FPrediction-Markets-Trading-Bot-Toolkits+loss&type=issues — GitHub-reported results: 0.

Additional inspected archive paths and pages (all 2026-10-14):

- https://github.com/marketlenstrade/polymarket-historical-data — root directory/file discovery.
- https://codeload.github.com/marketlenstrade/polymarket-historical-data/tar.gz/6eb9b8efda545eddafb2a8f75acb4bcbca6db019 — complete acquired source archive.
- https://codeload.github.com/Jon-Becker/prediction-market-analysis/tar.gz/refs/heads/main — research code archive, not the external 36 GiB dataset.
- https://codeload.github.com/Kalshi/tools-and-analysis/tar.gz/refs/heads/main — inspected notebook/code archive.
- https://raw.githubusercontent.com/marketlenstrade/polymarket-historical-data/main/targets.json — event selection definitions.
- https://raw.githubusercontent.com/marketlenstrade/polymarket-historical-data/main/apple-weekly-2026-06-12/markets.csv — initial metadata inspection.
- https://raw.githubusercontent.com/marketlenstrade/polymarket-historical-data/main/apple-weekly-2026-06-12/snapshots.csv — initial reference quote inspection, not used as full-depth execution data.
- https://raw.githubusercontent.com/marketlenstrade/polymarket-historical-data/main/nyc-weather-2026-07-16/markets.csv — initial metadata inspection.
- https://raw.githubusercontent.com/marketlenstrade/polymarket-historical-data/main/ufc-330-2026-08-16/markets.csv — initial metadata inspection.
- https://raw.githubusercontent.com/marketlenstrade/polymarket-historical-data/main/bitcoin-5m-15m-hourly-2026-06-15/markets.csv — initial metadata inspection.

Failed path-discovery requests (HTTP 404; not inspected sources and not proof a platform has no SDK):

- https://raw.githubusercontent.com/Polymarket/docs/main/README.md
- https://raw.githubusercontent.com/Kalshi/kalshi-python/master/README.md
- https://raw.githubusercontent.com/Kalshi/kalshi-python/main/README.md
- https://raw.githubusercontent.com/Kalshi/kalshi-starter-code/main/README.md
