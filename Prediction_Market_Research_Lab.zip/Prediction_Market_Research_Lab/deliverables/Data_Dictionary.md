# Data dictionary

The principal historical files contain no participant identities. Missing delayed quotes are missing execution evidence, never zero-price fills or zero losses. Prices are dollars per share and timestamps use UTC. Outcome labels are third-party reported.

## Historical_Data.csv

| Field | Type / unit | Missing rows | Definition and limitation |
| --- | --- | --- | --- |
| market_id | object / text or dimensionless | 0 | Provider-assigned market UUID; not an account or wallet identity. |
| event_cluster | object / text or dimensionless | 0 | Deterministic hashed event-group ID; all related contracts grouped for uncertainty and splits. |
| category | object / text or dimensionless | 0 | Broad category assigned by source chapter; one selected chapter per category. |
| chapter | object / text or dimensionless | 0 | Original source folder/event-window identifier. |
| question | object / text or dimensionless | 0 | Original public market question; not a trader identifier. |
| outcome_name | object / text or dimensionless | 0 | First named outcome whose probability and payout are normalized. |
| other_outcome_name | object / text or dimensionless | 0 | The second binary outcome. |
| winning_outcome | object / text or dimensionless | 0 | Provider-reported winning name; not independently corroborated by official settlement. |
| y | int64 / 0–1 | 0 | Binary payout of first named outcome: 1 if it is the reported winner, otherwise 0. |
| resolved_at | object / UTC ISO 8601 | 0 | Provider-reported settlement timestamp, UTC; also label-availability boundary. |
| close_time | object / UTC ISO 8601 | 0 | Provider-reported closing time, UTC; quote use stops at earlier close/resolution. |
| anchor_time | object / UTC ISO 8601 | 0 | First valid full archived two-sided preclose snapshot, UTC. May be in-play. |
| anchor_t_ms | int64 / milliseconds UTC epoch | 0 | Same anchor as integer milliseconds since Unix epoch. |
| p_market | float64 / 0–1 | 0 | Reference probability (anchor bid+ask)/2; not an executable price or trader forecast. |
| anchor_spread | float64 / USD/share or USD | 0 | Anchor ask minus bid, dollars per share. |
| source_commit | object / text or dimensionless | 0 | Pinned Git commit of public source archive. |
| data_kind | object / text or dimensionless | 0 | third_party_reported_historical; no synthetic or observed participant records in this CSV. |
| settlement_verification | object / text or dimensionless | 0 | provider_label_only; zero independent official label checks in this session. |

## Historical_Execution_Quotes.csv

| Field | Type / unit | Missing rows | Definition and limitation |
| --- | --- | --- | --- |
| market_id | object / text or dimensionless | 0 | Provider-assigned market UUID; not an account or wallet identity. |
| event_cluster | object / text or dimensionless | 0 | Deterministic hashed event-group ID; all related contracts grouped for uncertainty and splits. |
| category | object / text or dimensionless | 0 | Broad category assigned by source chapter; one selected chapter per category. |
| chapter | object / text or dimensionless | 0 | Original source folder/event-window identifier. |
| question | object / text or dimensionless | 0 | Original public market question; not a trader identifier. |
| outcome_name | object / text or dimensionless | 0 | First named outcome whose probability and payout are normalized. |
| other_outcome_name | object / text or dimensionless | 0 | The second binary outcome. |
| winning_outcome | object / text or dimensionless | 0 | Provider-reported winning name; not independently corroborated by official settlement. |
| y | int64 / 0–1 | 0 | Binary payout of first named outcome: 1 if it is the reported winner, otherwise 0. |
| resolved_at | object / UTC ISO 8601 | 0 | Provider-reported settlement timestamp, UTC; also label-availability boundary. |
| close_time | object / UTC ISO 8601 | 0 | Provider-reported closing time, UTC; quote use stops at earlier close/resolution. |
| anchor_time | object / UTC ISO 8601 | 0 | First valid full archived two-sided preclose snapshot, UTC. May be in-play. |
| anchor_t_ms | int64 / milliseconds UTC epoch | 0 | Same anchor as integer milliseconds since Unix epoch. |
| p_market | float64 / 0–1 | 0 | Reference probability (anchor bid+ask)/2; not an executable price or trader forecast. |
| anchor_spread | float64 / USD/share or USD | 0 | Anchor ask minus bid, dollars per share. |
| source_commit | object / text or dimensionless | 0 | Pinned Git commit of public source archive. |
| data_kind | object / text or dimensionless | 0 | third_party_reported_historical; no synthetic or observed participant records in this CSV. |
| settlement_verification | object / text or dimensionless | 0 | provider_label_only; zero independent official label checks in this session. |
| requested_delay_seconds | int64 / seconds | 0 | Requested delay from anchor; grid 0,30,60,300,900. |
| quote_time | object / UTC ISO 8601 | 1013 | UTC time of first valid full snapshot at/after delayed target; blank if none exists. |
| effective_delay_seconds | float64 / seconds | 1013 | Actual quote timestamp minus anchor timestamp. |
| additional_snapshot_wait_seconds | float64 / seconds | 1013 | Effective delay minus requested delay; eligibility cap 300 seconds. |
| bid | float64 / USD/share or USD | 1013 | Best positive bid of recorded first-outcome book, dollars/share; not a modeled entry. |
| ask | float64 / USD/share or USD | 1013 | Lowest positive ask of recorded first-outcome book, dollars/share; conditional paper entry. |
| bid_size | float64 / shares | 1013 | Summed posted shares at best bid price, not total bid-side depth. |
| ask_size | float64 / shares | 1013 | Summed posted shares at best ask price; conditional size gate uses this field. |
| midpoint | float64 / 0–1 | 1013 | Delayed quote (bid+ask)/2; reference price only. |
| spread | float64 / USD/share or USD | 1013 | Delayed quote ask minus bid, dollars/share. |
| execution_status | object / text or dimensionless | 0 | eligible, no_preclose_snapshot_after_delay, or snapshot_wait_exceeds_300s. Eligible is a data gate, not proof of fill. |

## Paper_Positions.csv

| Field | Type / unit | Missing rows | Definition and limitation |
| --- | --- | --- | --- |
| market_id | object / text or dimensionless | 0 | Provider-assigned market UUID; not an account or wallet identity. |
| event_cluster | object / text or dimensionless | 0 | Deterministic hashed event-group ID; all related contracts grouped for uncertainty and splits. |
| category | object / text or dimensionless | 0 | Broad category assigned by source chapter; one selected chapter per category. |
| chapter | object / text or dimensionless | 0 | Original source folder/event-window identifier. |
| question | object / text or dimensionless | 0 | Original public market question; not a trader identifier. |
| outcome_name | object / text or dimensionless | 0 | First named outcome whose probability and payout are normalized. |
| other_outcome_name | object / text or dimensionless | 0 | The second binary outcome. |
| winning_outcome | object / text or dimensionless | 0 | Provider-reported winning name; not independently corroborated by official settlement. |
| y | int64 / 0–1 | 0 | Binary payout of first named outcome: 1 if it is the reported winner, otherwise 0. |
| resolved_at | object / UTC ISO 8601 | 0 | Provider-reported settlement timestamp, UTC; also label-availability boundary. |
| close_time | object / UTC ISO 8601 | 0 | Provider-reported closing time, UTC; quote use stops at earlier close/resolution. |
| anchor_time | object / UTC ISO 8601 | 0 | First valid full archived two-sided preclose snapshot, UTC. May be in-play. |
| anchor_t_ms | int64 / milliseconds UTC epoch | 0 | Same anchor as integer milliseconds since Unix epoch. |
| p_market | float64 / 0–1 | 0 | Reference probability (anchor bid+ask)/2; not an executable price or trader forecast. |
| anchor_spread | float64 / USD/share or USD | 0 | Anchor ask minus bid, dollars per share. |
| source_commit | object / text or dimensionless | 0 | Pinned Git commit of public source archive. |
| data_kind | object / text or dimensionless | 0 | third_party_reported_historical; no synthetic or observed participant records in this CSV. |
| settlement_verification | object / text or dimensionless | 0 | provider_label_only; zero independent official label checks in this session. |
| requested_delay_seconds | int64 / seconds | 0 | Requested delay from anchor; grid 0,30,60,300,900. |
| quote_time | object / UTC ISO 8601 | 0 | UTC time of first valid full snapshot at/after delayed target; blank if none exists. |
| effective_delay_seconds | float64 / seconds | 0 | Actual quote timestamp minus anchor timestamp. |
| additional_snapshot_wait_seconds | float64 / seconds | 0 | Effective delay minus requested delay; eligibility cap 300 seconds. |
| bid | float64 / USD/share or USD | 0 | Best positive bid of recorded first-outcome book, dollars/share; not a modeled entry. |
| ask | float64 / USD/share or USD | 0 | Lowest positive ask of recorded first-outcome book, dollars/share; conditional paper entry. |
| bid_size | float64 / shares | 0 | Summed posted shares at best bid price, not total bid-side depth. |
| ask_size | float64 / shares | 0 | Summed posted shares at best ask price; conditional size gate uses this field. |
| midpoint | float64 / 0–1 | 0 | Delayed quote (bid+ask)/2; reference price only. |
| spread | float64 / USD/share or USD | 0 | Delayed quote ask minus bid, dollars/share. |
| execution_status | object / text or dimensionless | 0 | eligible, no_preclose_snapshot_after_delay, or snapshot_wait_exceeds_300s. Eligible is a data gate, not proof of fill. |
| split | object / text or dimensionless | 0 | Original event-group period: train, validation, test, purged_train, purged_validation. |
| skip_reason | float64 / text or dimensionless | 1770 | Blank for accepted conditional positions; otherwise records why a quote was not modeled as filled. |
| quantity | float64 / shares | 0 | Exactly one hypothetical share; not a recommended real order size. |
| gross_pnl | float64 / USD/share or USD | 0 | Hypothetical payout minus ask times quantity; already pays the bid–ask spread. |
| modeled_cost | float64 / USD/share or USD | 0 | Declared hypothetical additional cost per share times quantity; not verified exchange fees. |
| net_pnl | float64 / USD/share or USD | 0 | Gross conditional paper P&L less modeled cost, dollars. |
| outlay | float64 / USD/share or USD | 0 | Ask times quantity plus hypothetical additional cost, dollars. |
| return_on_outlay | float64 / text or dimensionless | 0 | Net modeled P&L/outlay; not return on participant capital. |

## Supporting outputs

Data_Audit.csv counts raw event/trade/snapshot validation findings by market. Excluded_Observations.csv lists one market-level exclusion reason. Period_Assignments.csv contains original event-group split labels. Forecast_Observations.csv adds the frozen adjustment to the normalized historical data. Forecast_Metrics.csv records score means, event counts and conditional 95% cluster intervals. Calibration.csv contains occupied ten-bin reliability statistics. Category_Metrics.csv and Paper_Category_Metrics.csv are descriptive category aggregates. Paper_Skips.csv preserves nonfills and reasons. Cost_Delay_Sensitivity.csv records all predeclared cost/delay scenarios for full and test cohorts. Matched_Delay_Comparisons.json records same-market later-minus-anchor P&L changes and clustered intervals. Robustness.json records exploratory sensitivity outcomes, including empty prior-category support.

Synthetic_Selection_Replications.csv contains one row per simulated world; its win rates are hypothetical, not observed users. Synthetic_Participant_Example.csv contains a representative zero-skill world with SYN IDs, trial counts, win rates and fair-coin P&L. Synthetic_Selection_Summary.json separates scenario percentiles from Monte Carlo standard errors. Source_Manifest.json contains inspected/blocked URLs, date and content hashes, never credentials. The design, selected-model and initial-test JSON files document frozen choices and evaluation boundaries.
