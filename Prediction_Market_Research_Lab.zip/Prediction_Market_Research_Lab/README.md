# Prediction Market Research Lab

Historical data / paper simulation only. No account connection, live odds, wallet tracking, trading API, orders or alerts.

The main participant-persistence question is unidentifiable in the acquired market-level archive. The lab contains actual downloaded **third-party reported historical** quotes/outcomes, a conditional paper-accounting benchmark, and a **separate explicitly synthetic zero-skill** selection experiment. It does not claim to measure real trader profitability or copied returns. No official settlement labels were independently corroborated because platform API access was blocked.

## Open the finished files

- `deliverables/Research_Report.pdf`: the professional report with source citations.
- `deliverables/Historical_Research_Dashboard.html`: open directly in a browser; the plotting library and data are embedded, with no internet needed.
- `deliverables/Backtest_Analysis.xlsx`: summary results, raw/derived observations, assumptions and paper-cashflow formulas. Numeric results are precomputed; formulas are set to recalculate on open. An Excel calculation engine was not used during verification.
- `deliverables/Research_Notebook.ipynb`: an executed analysis notebook; requires the lab’s source/data files to rerun.
- `deliverables/Historical_Data.csv`: 2,021 market records, not participant histories.
- `deliverables/Methodology.md`, `Data_Dictionary.md`, `Sources.md`: complete scope, field definitions and inspected/blocked source audit.
- `deliverables/Validation.json`: actual execution and artifact checks.

The full bundle also contains quote records, modeled positions and skips, event splits, clustered uncertainty, category/robustness results, synthetic repetitions, source metadata, original data license, editable report, publication charts, research code and tests.

## Reproduce without any network or account

Python 3.12 is used. Install dependencies once, using the hash-pinned lockfile. The commands below never connect to a trading platform:

```bash
cd /workspace/test/research  # or the extracted lab root
UV_CACHE_DIR="$PWD/.cache/uv" uv venv --python python .venv
UV_CACHE_DIR="$PWD/.cache/uv" uv pip sync --python .venv/bin/python requirements.lock
.venv/bin/python src/analysis.py develop
.venv/bin/python src/analysis.py evaluate
.venv/bin/python -m pytest tests -q
```

Installation needs package-registry access; **analysis after installation is entirely offline**. In a restored cloud task, reuse the existing isolated checkout and dependencies. Do not create a Git worktree unless the user explicitly requests one. Repeat runs reproduce the frozen design; the original holdout does not become an untouched new test.

For ordinary analysis use `.venv/bin/python` directly; no running server is required. The browser dashboard is a single self-contained HTML file. Do not expose a web preview or connect any platform account.

## Rebuild artifacts

```bash
.venv/bin/python src/build_deliverables.py
.venv/bin/python src/verify_deliverables.py
```

The first command rewrites the notebook source, so the second executes it again. Verification prints the PDF, opens the workbook, exercises the offline dashboard controls and repeats the analysis in a temporary directory. PDF/browser checks require a local `chromium` executable and `pandoc`. These were present in the prepared cloud environment. The supplied PDF, HTML, XLSX and CSV can be used without those build tools.

## Optional raw-archive audit

The compact bundle omits the roughly 157 MB compressed / 227 MB extracted public source archive. To repeat its full validation, explicitly download the pinned GitHub archive and run:

```bash
.venv/bin/python src/download_archive.py
.venv/bin/python src/prepare_data.py
```

The optional acquisition uses only a pinned public GitHub URL, not a live market API or account. It refuses to overwrite different existing archive content. Then run the offline analysis stages. The first source audit verified all 2,278 history hashes and 1,120,033 trade records; those outcomes are in the supplied audit/summary files. Source catalog regeneration additionally requires the original inspected-document cache, which is omitted from the compact bundle; the completed source audit itself is included.

## Rights and limits

Data attribution: **Marketlens, https://marketlens.trade**, public Polymarket Historical Data archive, commit `6eb9b8efda545eddafb2a8f75acb4bcbca6db019`, CC BY 4.0. Full license and transformation details are included. Source coverage is selected events, not every platform market. All copying-provider earnings claims are unverified unless specifically stated otherwise; no claim is represented as independently audited realized profit.

Twenty-eight inspected documents/search pages are cataloged, with additional discovery queries logged separately. Broader web search, Reddit, academic full texts and official platform docs/APIs were unavailable under the current network policy. The external large archive was not acquired. A draft network update is saved, but has not been applied/published or independently retested. See Sources.md for the exact domains and follow-up evidence needed. None of those permissions is necessary for the supplied offline analyses.
