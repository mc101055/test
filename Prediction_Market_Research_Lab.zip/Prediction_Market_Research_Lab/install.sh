#!/usr/bin/env bash
set -euo pipefail
cd /workspace/test/research
export UV_CACHE_DIR=/workspace/test/research/.cache/uv
export XDG_CACHE_HOME=/workspace/test/research/.cache
export MPLCONFIGDIR=/workspace/test/research/.cache/matplotlib
mkdir -p "$UV_CACHE_DIR" "$MPLCONFIGDIR"
python -c 'import sys; assert sys.version_info[:2] == (3, 12), "The lab uses Python 3.12"'
if [ ! -x .venv/bin/python ]; then
    uv venv --python python .venv
fi
uv pip sync --python .venv/bin/python --require-hashes requirements.lock
.venv/bin/python -c 'import numpy, pandas, matplotlib, openpyxl, plotly, nbformat, nbclient, pyarrow; print("Research dependencies available")'
