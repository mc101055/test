"""Exercise offline artifacts, execute notebook, print report and record validation evidence."""
from __future__ import annotations
import asyncio
import base64
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime,timezone

ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'deliverables';CACHE=ROOT/'.cache'
for variable,part in [('MPLCONFIGDIR','matplotlib'),('XDG_CACHE_HOME',''),('IPYTHONDIR','ipython'),
                      ('JUPYTER_RUNTIME_DIR','jupyter/runtime'),('JUPYTER_CONFIG_DIR','jupyter/config')]:
    p=CACHE/part;p.mkdir(parents=True,exist_ok=True);os.environ[variable]=str(p)
import numpy as np
import pandas as pd
from openpyxl import load_workbook
import nbformat
from nbclient import NotebookClient
from pypdf import PdfReader
from playwright.async_api import async_playwright

def execute_notebook():
    kernel=CACHE/'jupyter/kernels/research-lab';kernel.mkdir(parents=True,exist_ok=True)
    (kernel/'kernel.json').write_text(json.dumps({'argv':[sys.executable,'-m','ipykernel_launcher','-f','{connection_file}'],
        'display_name':'Research lab Python','language':'python'}))
    os.environ['JUPYTER_PATH']=str(CACHE/'jupyter')
    p=OUT/'Research_Notebook.ipynb';nb=nbformat.read(p,as_version=4)
    client=NotebookClient(nb,timeout=180,kernel_name='research-lab',resources={'metadata':{'path':str(ROOT)}})
    client.execute();nbformat.write(nb,p)
    code=[c for c in nb.cells if c.cell_type=='code']
    assert all(c.execution_count is not None for c in code)
    assert not any(o.output_type=='error' for c in code for o in c.outputs)
    return {'code_cells_executed':len(code),'errors':0}

def check_spreadsheet():
    wb=load_workbook(OUT/'Backtest_Analysis.xlsx',read_only=True,data_only=False)
    ws=wb['Primary_Paper'];n=ws.max_row-1
    df=pd.read_csv(OUT/'Paper_Positions.csv');assert n==len(df)
    net=0.0
    for row_num,row in enumerate(ws.iter_rows(min_row=2,values_only=True),2):
        qty,y,ask,cost=row[3],row[4],row[5],row[6]
        calculated=qty*y-qty*ask-cost
        assert np.isclose(calculated,row[8])
        assert row[15]==f'=D{row_num}*(E{row_num}-F{row_num})'
        assert row[16]==f'=D{row_num}*E{row_num}-D{row_num}*F{row_num}-G{row_num}'
        assert row[17]==f'=D{row_num}*F{row_num}+G{row_num}'
        assert row[18]==f'=Q{row_num}/R{row_num}'
        net+=calculated
    assert np.isclose(net,df.net_pnl.sum())
    assert wb['Historical_Data'].max_row==2022
    count=len(wb.sheetnames);wb.close()
    return {'sheets_opened':count,'paper_rows_reconciled':n,'formula_references_checked':n*4,
            'excel_formula_engine_executed':False,'numeric_summaries_and_formula_identities_verified':True}

def reproduce_pipeline():
    with tempfile.TemporaryDirectory(prefix='prediction_research_verify_',dir='/tmp') as temp:
        root=Path(temp);(root/'deliverables').mkdir();(root/'src').mkdir()
        shutil.copy(ROOT/'Research_Design.json',root/'Research_Design.json')
        shutil.copy(ROOT/'src/analysis.py',root/'src/analysis.py')
        for name in ['Historical_Data.csv','Historical_Execution_Quotes.csv','Data_Summary.json']:
            shutil.copy(OUT/name,root/'deliverables'/name)
        for stage in ['develop','evaluate']:
            result=subprocess.run([sys.executable,str(root/'src/analysis.py'),stage],capture_output=True,text=True)
            if result.returncode:raise RuntimeError(result.stderr)
        original=json.loads((OUT/'Results.json').read_text());new=json.loads((root/'deliverables/Results.json').read_text())
        for key in ['primary_paper_benchmark','primary_test_paper_benchmark','forecast_metrics','synthetic_null','matched_delay_comparisons']:
            assert original[key]==new[key], 'Reproduction mismatch: '+key
    return {'fresh_directory_offline_pipeline':True,'matching_result_groups':5,'accounts_or_network_used':False}

def report_html():
    # Currency signs in financial prose must not become inline TeX delimiters.
    body=subprocess.check_output(['pandoc',str(OUT/'Research_Report.md'),'-f','gfm-tex_math_dollars','-t','html5'],text=True)
    css="""@page{size:A4;margin:19mm 17mm 19mm 17mm}body{font-family:Arial, sans-serif;font-size:10.4pt;line-height:1.55;color:#263647;margin:0}h1{font-size:34pt;line-height:1.08;letter-spacing:-1pt;color:#103f50;margin:12mm 0 4mm}h2{font-size:19pt;line-height:1.2;color:#105b60;margin:8mm 0 3mm;break-after:avoid}h3{font-size:12pt;color:#173d50;margin-top:5mm;break-after:avoid}p{margin:3mm 0}strong{color:#1b4052}a{color:#117d8a;overflow-wrap:anywhere}table{width:100%;border-collapse:collapse;font-size:8pt;line-height:1.35;margin:4mm 0;table-layout:fixed}th,td{border:1px solid #d9e3e8;padding:2mm;vertical-align:top;overflow-wrap:anywhere}thead{display:table-header-group}th{background:#e9f1f3;color:#214656}tr{break-inside:avoid}img{display:block;max-width:100%;max-height:90mm;margin:5mm auto;object-fit:contain}figure{break-inside:avoid}li{margin:2mm 0}code{font-size:8.3pt;background:#eef3f5;padding:1px 3px;overflow-wrap:anywhere}hr{border:0;border-top:1px solid #d8e1e7}blockquote{border-left:3px solid #117c80;padding-left:4mm;color:#3d5261}p:has(img){break-inside:avoid}h2:first-of-type{font-size:15pt;color:#526773}ul:last-child li{font-size:8pt;overflow-wrap:anywhere}"""
    from bs4 import BeautifulSoup
    parsed=BeautifulSoup(body,'html.parser')
    for image in parsed.find_all('img'):
        resource=(OUT/image['src']).resolve()
        if not resource.is_relative_to(OUT):raise ValueError('Report image outside artifact directory')
        image['src']='data:image/png;base64,'+base64.b64encode(resource.read_bytes()).decode()
    path=OUT/'Research_Report.html';path.write_text('<!doctype html><html><head><meta charset="utf-8"><title>Prediction Market Research Lab</title><style>'+css+'</style></head><body>'+str(parsed)+'</body></html>')
    return path

async def browser_checks():
    errors=[];network=[]
    async with async_playwright() as p:
        browser=await p.chromium.launch(executable_path=shutil.which('chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
        context=await browser.new_context(viewport={'width':1440,'height':1080},device_scale_factor=1)
        await context.set_offline(True)
        page=await context.new_page()
        page.on('pageerror',lambda e:errors.append(str(e)))
        page.on('request',lambda r:network.append(r.url) if r.url.startswith(('http://','https://')) else None)
        # The managed browser disallows file:// navigation. Render the authorized local
        # single-file contents directly; do not disable or change its URL policy.
        await page.set_content((OUT/'Historical_Research_Dashboard.html').read_text(),wait_until='load')
        await page.wait_for_function('window.LAB_READY === true')
        state=await page.evaluate('window.LAB_STATE')
        assert state['markets']==2021 and state['fills']==1770
        assert abs(state['net']+62.6495)<1e-8
        assert abs(state['brier']-.17846142256308758)<1e-4
        await page.screenshot(path=str(OUT/'Dashboard_Overview.png'),full_page=True)
        for tab in ['profitability','forecasts','paper','sensitivity','reliability']:
            await page.locator('button[data-tab="'+tab+'"]').click()
            await page.wait_for_timeout(100)
            assert await page.locator('#'+tab).is_visible()
        await page.locator('button[data-tab="paper"]').click()
        await page.select_option('#cost','0.05')
        expensive=await page.evaluate('window.LAB_STATE')
        assert abs(expensive['net']-(state['net']-1770*.04))<1e-8
        await page.select_option('#delay','300')
        delayed=await page.evaluate('window.LAB_STATE')
        assert delayed['fills']==718 and delayed['skipped']==1303
        await page.select_option('#category','Crypto')
        assert (await page.evaluate('window.LAB_STATE'))['markets']==288
        await page.select_option('#category','All');await page.select_option('#period','test')
        assert (await page.evaluate('window.LAB_STATE'))['markets']==93
        await page.select_option('#period','All');await page.select_option('#delay','0');await page.select_option('#cost','0.01')
        await page.locator('button[data-tab="forecasts"]').click();await page.wait_for_timeout(200)
        await page.screenshot(path=str(OUT/'Dashboard_Forecasts.png'),full_page=True)
        await page.locator('button[data-tab="profitability"]').click()
        await page.fill('#minimum','130');await page.dispatch_event('#minimum','input')
        assert (await page.evaluate('window.SYN_STATE'))['eligible']==0
        await page.fill('#minimum','20');await page.dispatch_event('#minimum','input')
        await page.locator('#train').evaluate("e=>{e.value='70';e.dispatchEvent(new Event('input'));}")
        assert (await page.evaluate('window.SYN_STATE'))['trainingTrials']==140
        assert (await page.evaluate('window.SYN_STATE'))['testTrials']==20
        await page.locator('#train').evaluate("e=>{e.value='60';e.dispatchEvent(new Event('input'));}")
        await page.set_viewport_size({'width':390,'height':844})
        await page.wait_for_timeout(200)
        assert await page.evaluate('document.documentElement.scrollWidth <= window.innerWidth+2')
        await page.screenshot(path=str(OUT/'Dashboard_Mobile.png'),full_page=True)
        await page.set_viewport_size({'width':1440,'height':1080})
        report_page=await context.new_page()
        await report_page.set_content(report_html().read_text(),wait_until='load')
        await report_page.pdf(path=str(OUT/'Research_Report.pdf'),format='A4',print_background=True,display_header_footer=True,
            header_template='<div style="font-size:8px;width:100%;margin:0 17mm;color:#6b7e8b">PREDICTION MARKET RESEARCH LAB · HISTORICAL / PAPER ONLY</div>',
            footer_template='<div style="font-size:8px;width:100%;margin:0 17mm;color:#6b7e8b">October 14, 2026 <span style="float:right"><span class="pageNumber"></span> / <span class="totalPages"></span></span></div>',
            margin={'top':'19mm','bottom':'19mm','left':'17mm','right':'17mm'})
        await browser.close()
    assert not errors,errors
    assert not network,network
    reader=PdfReader(OUT/'Research_Report.pdf');text='\n'.join(p.extract_text() or '' for p in reader.pages)
    assert len(reader.pages)>=10 and len(text)>20000
    assert 'Final conclusion' in text and 'Marketlens' in text
    assert not any('{{' in (p.extract_text() or '') for p in reader.pages)
    assert all(amount in text for amount in ['−$44.95','−$62.65','−$4.97','$39.98','$17.70']), 'Currency notation was lost in PDF rendering'
    assert '**' not in text, 'Unrendered Markdown in PDF'
    return {'dashboard_offline_load':True,'load_method':'authorized local HTML content embedded in offline browser; managed file-URL navigation blocked','dashboard_tabs_checked':6,'cost_delay_category_period_and_synthetic_controls_checked':True,
        'mobile_overflow_check_passed':True,'external_dashboard_requests':len(network),'javascript_errors':len(errors),
        'pdf_pages':len(reader.pages),'pdf_text_characters':len(text),'literal_currency_formatting_verified':True}

def main():
    print('Executing research notebook...',flush=True);notebook=execute_notebook()
    print('Opening and reconciling workbook...',flush=True);workbook=check_spreadsheet()
    print('Reproducing analysis offline in a fresh directory...',flush=True);pipeline=reproduce_pipeline()
    print('Opening dashboard offline, exercising controls, and printing PDF...',flush=True);browser=asyncio.run(browser_checks())
    result=subprocess.run([sys.executable,'-m','pytest',str(ROOT/'tests'),'-q'],cwd=ROOT,capture_output=True,text=True)
    assert result.returncode==0,result.stdout+result.stderr
    evidence={'completed_at_utc':datetime.now(timezone.utc).isoformat(),'notebook':notebook,'workbook':workbook,
        'pipeline':pipeline,'browser_and_pdf':browser,'automated_checks':result.stdout.strip(),
        'scope_limits':['no participant panel','no acquired Kalshi numeric dataset','no independent official settlement validation',
                        'blocked broad web/Reddit/academic research','conditional execution and hypothetical additional costs']}
    (OUT/'Validation.json').write_text(json.dumps(evidence,indent=2))
    print(json.dumps(evidence,indent=2))

if __name__=='__main__':main()
