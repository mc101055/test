"""Validate the pinned public archive and produce a small, account-free offline dataset."""
from __future__ import annotations
import csv
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
import pyarrow.compute as pc
import pyarrow.parquet as pq

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / 'data/raw_marketlens'
OUT = ROOT / 'deliverables'
DATA = ROOT / 'data'
COMMIT = '6eb9b8efda545eddafb2a8f75acb4bcbca6db019'
CUTOFF = pd.Timestamp('2026-10-14T00:00:00Z')
DELAYS = [0, 30, 60, 300, 900]
MAX_WAIT_SECONDS = 300
CATEGORIES = {
    'bitcoin': 'Crypto', 'mlb': 'Sports / baseball', 'world': 'Sports / soccer',
    'ufc': 'Sports / combat', 'counter': 'Esports', 'nyc': 'Weather', 'apple': 'Equities',
}

def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        while b := f.read(1 << 20): h.update(b)
    return h.hexdigest()

def top_level(s, bid):
    if not s: return np.nan, 0.0, 'empty_book_side'
    try:
        levels = json.loads(s)
        parsed = [(float(x['price']), float(x['size'])) for x in levels]
        if any(not np.isfinite(p) or not np.isfinite(q) or p < 0 or p > 1 or q < 0 for p, q in parsed):
            return np.nan, 0.0, 'invalid_book_level'
        parsed = [(p, q) for p, q in parsed if q > 0]
        if not parsed: return np.nan, 0.0, 'empty_book_side'
        p = (max if bid else min)(x[0] for x in parsed)
        return p, sum(q for p0, q in parsed if p0 == p), ''
    except (ValueError, TypeError, KeyError):
        return np.nan, 0.0, 'malformed_book'

def build():
    OUT.mkdir(exist_ok=True); DATA.mkdir(exist_ok=True)
    manifest = json.loads((RAW / 'manifest.json').read_text())
    audit, exclusions, quotes, markets, hashes = [], [], [], [], []
    for chapter in manifest['chapters']:
        folder = RAW / chapter['folder']
        meta = pd.read_csv(folder / 'markets.csv', keep_default_na=False)
        assert len(meta) == chapter['markets']
        assert not meta.market_id.duplicated().any()
        expected = {x['file']: x for x in chapter['files']}
        category = CATEGORIES[chapter['folder'].split('-')[0]]
        for _, m in meta.iterrows():
            mid = m.market_id
            fn = folder / m['file']
            expected_row = expected[m['file']]
            sha = digest(fn)
            if sha != expected_row['sha256']: raise ValueError(f'Checksum mismatch: {fn.name}')
            if pq.read_metadata(fn).num_rows != expected_row['rows']: raise ValueError('Row count mismatch')
            hashes.append({'path': str(fn.relative_to(ROOT)), 'sha256': sha, 'rows': expected_row['rows']})
            tape = pq.read_table(fn, columns=['event_type', 't', 'price', 'size', 'trade_id'])
            timestamps = tape['t'].to_numpy()
            trade = tape.filter(pc.equal(tape['event_type'], 'trade')).to_pandas()
            duplicate_trade = int(trade.duplicated('trade_id').sum())
            missing_trade_id = int(trade.trade_id.isna().sum())
            invalid_trade = int((~trade.price.between(0, 1) | ~np.isfinite(trade.price) |
                                 ~np.isfinite(trade['size']) | (trade['size'] < 0)).sum())
            basic = {'market_id': mid, 'chapter': chapter['folder'], 'raw_rows': len(timestamps),
                     'trade_rows': len(trade), 'duplicate_trade_ids': duplicate_trade,
                     'missing_trade_ids': missing_trade_id, 'invalid_trade_rows': invalid_trade,
                     'unsorted_raw_timestamps': int(np.any(np.diff(timestamps) < 0))}
            outcomes = m.outcomes.split('|')
            if len(outcomes) != 2 or len(set(outcomes)) != 2 or m.winning_outcome not in outcomes:
                exclusions.append({'market_id': mid, 'reason': 'missing_ambiguous_or_nonbinary_settlement'})
                audit.append(basic); continue
            opened, closed, resolved = (pd.to_datetime(m[x], utc=True, errors='coerce') for x in
                                        ['open_time', 'close_time', 'resolved_at'])
            if any(pd.isna(x) for x in [opened, closed, resolved]) or resolved >= CUTOFF:
                exclusions.append({'market_id': mid, 'reason': 'invalid_or_nonhistorical_metadata_time'})
                audit.append(basic); continue
            if m.series in ['btc-up-or-down-15m', 'btc-up-or-down-hourly']:
                exclusions.append({'market_id': mid, 'reason': 'overlapping_crypto_cadence_excluded'})
                audit.append(basic); continue
            table = pq.read_table(fn, columns=['event_type', 't', 'bids', 'asks', 'is_reseed'])
            snap = table.filter(pc.equal(table['event_type'], 'snapshot')).to_pandas()
            bids = [top_level(s, True) for s in snap.bids]
            asks = [top_level(s, False) for s in snap.asks]
            snap['bid'] = [x[0] for x in bids]; snap['bid_size'] = [x[1] for x in bids]
            snap['ask'] = [x[0] for x in asks]; snap['ask_size'] = [x[1] for x in asks]
            snap['timestamp'] = pd.to_datetime(snap.t, unit='ms', utc=True, errors='coerce')
            end = min(closed, resolved)
            valid_time = snap.timestamp.notna() & (snap.timestamp < end) & (snap.timestamp < CUTOFF)
            valid_book = snap.bid.between(0, 1, inclusive='neither') & snap.ask.between(0, 1, inclusive='neither') & (snap.bid <= snap.ask)
            basic.update({'snapshot_rows': len(snap), 'invalid_or_empty_book_snapshots': int((~valid_book).sum()),
                          'snapshots_at_or_after_close_or_resolution': int((~valid_time).sum()),
                          'reseed_snapshots': int(snap.is_reseed.fillna(False).sum()),
                          'exact_duplicate_snapshots': int(snap.duplicated(['t', 'bid', 'ask', 'bid_size', 'ask_size']).sum())})
            good = snap[valid_time & valid_book].drop_duplicates(['t', 'bid', 'ask', 'bid_size', 'ask_size'])
            # Conflicting simultaneous book states cannot establish temporal ordering.
            conflict_times = good.loc[good.duplicated('t', keep=False), 't'].unique()
            basic['conflicting_snapshot_times'] = len(conflict_times)
            good = good[~good.t.isin(conflict_times)].sort_values('t', kind='stable')
            audit.append(basic)
            if good.empty:
                exclusions.append({'market_id': mid, 'reason': 'no_valid_two_sided_preclose_snapshot'})
                continue
            anchor = good.iloc[0]
            event_key = (f'crypto-hour-{opened.floor("h").isoformat()}' if category == 'Crypto'
                         else chapter['folder'] + '|' + m.event)
            cluster = 'E' + hashlib.sha256(event_key.encode()).hexdigest()[:12]
            cm = {'market_id': mid, 'event_cluster': cluster, 'category': category,
                  'chapter': chapter['folder'], 'question': m.question, 'outcome_name': outcomes[0],
                  'other_outcome_name': outcomes[1], 'winning_outcome': m.winning_outcome,
                  'y': int(m.winning_outcome == outcomes[0]), 'resolved_at': resolved.isoformat(),
                  'close_time': closed.isoformat(), 'anchor_time': anchor.timestamp.isoformat(),
                  'anchor_t_ms': int(anchor.t), 'p_market': float((anchor.bid + anchor.ask) / 2),
                  'anchor_spread': float(anchor.ask-anchor.bid), 'source_commit': COMMIT,
                  'data_kind': 'third_party_reported_historical', 'settlement_verification': 'provider_label_only'}
            markets.append(cm)
            for delay in DELAYS:
                target = anchor.timestamp + pd.Timedelta(seconds=delay)
                available = good[good.timestamp >= target]
                if available.empty:
                    quotes.append({**cm, 'requested_delay_seconds': delay, 'execution_status': 'no_preclose_snapshot_after_delay'})
                    continue
                book = available.iloc[0]
                wait = (book.timestamp-target).total_seconds()
                status = 'eligible' if wait <= MAX_WAIT_SECONDS else 'snapshot_wait_exceeds_300s'
                quotes.append({**cm, 'requested_delay_seconds': delay, 'quote_time': book.timestamp.isoformat(),
                    'effective_delay_seconds': (book.timestamp-anchor.timestamp).total_seconds(),
                    'additional_snapshot_wait_seconds': wait, 'bid': float(book.bid), 'ask': float(book.ask),
                    'bid_size': float(book.bid_size), 'ask_size': float(book.ask_size),
                    'midpoint': float((book.bid+book.ask)/2), 'spread': float(book.ask-book.bid),
                    'execution_status': status})
        print('Validated', chapter['folder'], flush=True)
    pd.DataFrame(audit).to_csv(OUT/'Data_Audit.csv', index=False)
    pd.DataFrame(exclusions).to_csv(OUT/'Excluded_Observations.csv', index=False)
    historical = pd.DataFrame(markets).sort_values(['anchor_t_ms', 'market_id'])
    historical.to_csv(OUT/'Historical_Data.csv', index=False)
    q = pd.DataFrame(quotes).sort_values(['anchor_t_ms', 'market_id', 'requested_delay_seconds'])
    q.to_csv(OUT/'Historical_Execution_Quotes.csv', index=False)
    (DATA/'Archive_File_Hashes.json').write_text(json.dumps(hashes, indent=2))
    stats = {'source_markets': manifest['totals']['markets'], 'source_event_rows': manifest['totals']['rows'],
             'retained_markets': len(historical), 'retained_event_clusters': historical.event_cluster.nunique(),
             'excluded_markets': len(exclusions), 'exclusion_reasons': pd.Series([x['reason'] for x in exclusions]).value_counts().to_dict(),
             'quote_records': len(q), 'trade_rows_audited': int(pd.DataFrame(audit).trade_rows.sum()),
             'first_forecast_time': historical.anchor_time.min(), 'last_resolution_time': historical.resolved_at.max(),
             'checksum_files_verified': len(hashes), 'official_settlements_independently_verified': 0,
             'participant_records': 0, 'source_commit': COMMIT, 'all_markets_settled_in_source': True}
    (OUT/'Data_Summary.json').write_text(json.dumps(stats, indent=2))
    print(json.dumps(stats, indent=2))

if __name__ == '__main__': build()
