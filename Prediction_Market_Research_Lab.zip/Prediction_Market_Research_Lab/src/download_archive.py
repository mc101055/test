"""Optional public archive acquisition; no platform account or live-market API."""
from pathlib import Path
import hashlib
import tarfile
import urllib.request

ROOT=Path(__file__).resolve().parents[1]
COMMIT='6eb9b8efda545eddafb2a8f75acb4bcbca6db019'
URL='https://codeload.github.com/marketlenstrade/polymarket-historical-data/tar.gz/'+COMMIT

def main():
    cache=ROOT/'sources/raw';cache.mkdir(parents=True,exist_ok=True)
    archive=cache/'marketlens_archive.tar.gz'
    if not archive.exists():
        partial=archive.with_suffix('.partial')
        with urllib.request.urlopen(URL,timeout=60) as r,partial.open('wb') as f:
            while b:=r.read(1<<20):f.write(b)
        partial.rename(archive)
    dest=ROOT/'data/raw_marketlens';dest.mkdir(parents=True,exist_ok=True)
    with tarfile.open(archive) as t:
        for m in t.getmembers():
            if not m.isfile():continue
            p=Path(m.name)
            if p.is_absolute() or '..' in p.parts:raise ValueError('Unsafe archive path')
            target=dest.joinpath(*p.parts[1:]);target.parent.mkdir(parents=True,exist_ok=True)
            content=t.extractfile(m).read()
            if target.exists() and hashlib.sha256(target.read_bytes()).digest()!=hashlib.sha256(content).digest():
                raise ValueError('Refusing to overwrite different existing archive content')
            if not target.exists():target.write_bytes(content)
    print('Pinned archive available; run src/prepare_data.py to verify each Parquet checksum.')

if __name__=='__main__':main()
