"""Offline research. This module has no network client, credentials, or order interface."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'deliverables'
SEED = 20261014

def clean_json(x):
    if isinstance(x, dict): return {str(k): clean_json(v) for k,v in x.items()}
    if isinstance(x, (list, tuple)): return [clean_json(v) for v in x]
    if isinstance(x, (np.integer,)): return int(x)
    if isinstance(x, (np.floating, float)): return float(x) if np.isfinite(x) else None
    if isinstance(x, np.ndarray): return clean_json(x.tolist())
    return x

def save(name, x):
    (OUT / name).write_text(json.dumps(clean_json(x), indent=2, allow_nan=False))

def read_data():
    d = pd.read_csv(OUT / 'Historical_Data.csv')
    for c in ['anchor_time', 'resolved_at', 'close_time']: d[c] = pd.to_datetime(d[c], utc=True, format='ISO8601')
    return d

def assign_splits(d, train_fraction=0.6, validation_fraction=0.2):
    d = d.copy()
    groups = d.groupby('event_cluster').agg(first=('anchor_time','min'), last_resolved=('resolved_at','max'))
    groups = groups.sort_values(['first','event_cluster'], kind='stable')
    n = len(groups); n_train = int(n*train_fraction); n_val = int(n*validation_fraction)
    if min(n_train, n_val, n-n_train-n_val) < 1: raise ValueError('Not enough event groups')
    groups['split'] = ['train']*n_train + ['validation']*n_val + ['test']*(n-n_train-n_val)
    validation_start = groups[groups.split=='validation']['first'].min()
    test_start = groups[groups.split=='test']['first'].min()
    groups.loc[(groups.split=='train') & (groups.last_resolved >= validation_start), 'split'] = 'purged_train'
    groups.loc[(groups.split=='validation') & (groups.last_resolved >= test_start), 'split'] = 'purged_validation'
    d['split'] = d.event_cluster.map(groups.split)
    for earlier, later in [('train','validation'), ('validation','test'), ('train','test')]:
        a,b = d[d.split==earlier],d[d.split==later]
        if not a.empty and not b.empty:
            assert a.resolved_at.max() < b.anchor_time.min(), 'Label-availability leakage'
            assert set(a.event_cluster).isdisjoint(b.event_cluster), 'Correlated event leakage'
    return d

def metric_values(y, p):
    y,p = np.asarray(y,float),np.asarray(p,float)
    if y.shape != p.shape or len(y)==0 or not np.all(np.isin(y,[0,1])) or not np.all((p>=0)&(p<=1)):
        raise ValueError('Invalid metric input')
    clipped=np.clip(p,1e-6,1-1e-6)
    return {'brier': (p-y)**2, 'log_loss': -(y*np.log(clipped)+(1-y)*np.log(1-clipped)),
            'accuracy': ((p>=0.5)==y).astype(float)}

def cluster_interval(d, values, cluster='event_cluster', repetitions=2000):
    g=pd.DataFrame({'group':d[cluster].to_numpy(), 'value':np.asarray(values,float)}).groupby('group').value.agg(['sum','count'])
    point=float(g['sum'].sum()/g['count'].sum())
    if len(g)<2: return {'estimate':point,'ci_low':None,'ci_high':None,'clusters':len(g)}
    rng=np.random.default_rng(SEED)
    draws=rng.integers(0,len(g),size=(repetitions,len(g)))
    boot=g['sum'].to_numpy()[draws].sum(1)/g['count'].to_numpy()[draws].sum(1)
    lo,hi=np.quantile(boot,[0.025,0.975])
    return {'estimate':point,'ci_low':float(lo),'ci_high':float(hi),'clusters':len(g)}

def sign_flip_p(d, values, repetitions=10000):
    g=pd.DataFrame({'g':d.event_cluster.to_numpy(),'v':values}).groupby('g').v.sum().to_numpy()
    if len(g)<5: return None
    rng=np.random.default_rng(SEED)
    null=(rng.choice([-1,1],size=(repetitions,len(g)))*g).sum(axis=1)
    return float((1+(np.abs(null)>=abs(g.sum())).sum())/(repetitions+1))

def develop():
    d=assign_splits(read_data())
    d[['market_id','event_cluster','split']].to_csv(OUT/'Period_Assignments.csv',index=False)
    train=d[d.split=='train']; valid=d[d.split=='validation']
    if train.empty or valid.empty: raise ValueError('No usable development periods')
    candidates=[]
    for shrinkage in [0.0,0.25,0.5]:
        p=(1-shrinkage)*valid.p_market.to_numpy()+shrinkage*0.5
        candidates.append({'shrinkage':shrinkage,'validation_brier':float(np.mean((p-valid.y.to_numpy())**2))})
    selected=min(candidates,key=lambda x:(x['validation_brier'],x['shrinkage']))
    frozen={'shrinkage':selected['shrinkage'], 'training_event_rate':float(train.y.mean()),
            'training_n':len(train),'validation_n':len(valid),'candidates':candidates,
            'design_sha256':hashlib.sha256((ROOT/'Research_Design.json').read_bytes()).hexdigest(),
            'development_data_sha256':hashlib.sha256((OUT/'Historical_Data.csv').read_bytes()).hexdigest(),
            'development_completed_at_utc':datetime.now(timezone.utc).isoformat(),
            'test_labels_used_for_selection':False}
    save('Selected_Model.json',frozen)
    print(json.dumps(clean_json(frozen),indent=2))

def simulate(q, cost=0.01, delay=0, spread_limit=0.2, quantity=1.0):
    """First named outcome only. Fills are conditional on the recorded quote, not guaranteed."""
    z=q[q.requested_delay_seconds==delay].copy()
    z['skip_reason']=z.execution_status.where(z.execution_status!='eligible','')
    z.loc[(z.skip_reason=='') & ((z.ask_size<quantity)|z.ask_size.isna()),'skip_reason']='insufficient_best_ask_depth'
    z.loc[(z.skip_reason=='') & (z.spread>spread_limit),'skip_reason']='spread_exceeds_limit'
    z.loc[(z.skip_reason=='') & (~z.ask.between(0,1,inclusive='neither')),'skip_reason']='invalid_ask'
    accepted=z[z.skip_reason==''].copy()
    accepted['quantity']=quantity
    accepted['gross_pnl']=quantity*(accepted.y-accepted.ask)
    accepted['modeled_cost']=quantity*cost
    accepted['net_pnl']=accepted.gross_pnl-accepted.modeled_cost
    accepted['outlay']=quantity*(accepted.ask+cost)
    accepted['return_on_outlay']=accepted.net_pnl/accepted.outlay
    # Exact contractual cashflow identity; fees here are declared hypothetical.
    assert np.allclose(accepted.net_pnl,quantity*accepted.y-accepted.outlay)
    return accepted,z[z.skip_reason!='']

def simulation_summary(rows, skipped, cost, delay, label='all'):
    if rows.empty:return {'sample':label,'cost':cost,'delay':delay,'filled':0,'skipped':len(skipped)}
    interval=cluster_interval(rows,rows.net_pnl)
    ordered=rows.sort_values(['resolved_at','market_id'])
    settled=ordered.groupby('resolved_at').net_pnl.sum().cumsum()
    peak=settled.cummax().clip(lower=0)
    cashflow_decline=float((peak-settled).max())
    return {'sample':label,'cost':cost,'delay':delay,'filled':len(rows),'skipped':len(skipped),
            'event_clusters':rows.event_cluster.nunique(),'gross_pnl':float(rows.gross_pnl.sum()),
            'net_pnl':float(rows.net_pnl.sum()),'total_outlay':float(rows.outlay.sum()),
            'return_on_aggregate_outlay':float(rows.net_pnl.sum()/rows.outlay.sum()),
            'favorable_fraction':float((rows.net_pnl>0).mean()),'median_return_on_outlay':float(rows.return_on_outlay.median()),
            'mean_net_pnl_per_share':interval['estimate'],'mean_ci_low':interval['ci_low'],'mean_ci_high':interval['ci_high'],
            'max_decline_in_cumulative_settled_pnl':cashflow_decline,
            'median_effective_delay_seconds':float(rows.effective_delay_seconds.median()),
            'actual_platform_fees_reconstructed':False,'portfolio_equity_drawdown_computed':False}

def synthetic_experiment(train_fraction=0.6, min_observations=20, repetitions=250, seed=SEED):
    rng=np.random.default_rng(seed); n=1000; trials=200; nt=int(trials*train_fraction); nv=int(trials*0.2)
    ns=trials-nt-nv
    if nt<min_observations or ns<1: raise ValueError('Insufficient synthetic period observations')
    records=[]; example=None
    for rep in range(repetitions):
        wins=rng.integers(0,2,size=(n,trials),dtype=np.int8)
        tr=wins[:,:nt].mean(1); va=wins[:,nt:nt+nv].mean(1); te=wins[:,nt+nv:].mean(1)
        chosen=np.argsort(-tr,kind='stable')[:50]
        oracle=np.argsort(-te,kind='stable')[:50]
        records.append({'repetition':rep,'selected_train_win_rate':float(tr[chosen].mean()),
            'selected_validation_win_rate':float(va[chosen].mean()),'selected_test_win_rate':float(te[chosen].mean()),
            'population_test_win_rate':float(te.mean()),'forbidden_test_selected_win_rate':float(te[oracle].mean()),
            'selected_test_positive_pnl_fraction':float((te[chosen]>0.5).mean())})
        if rep==0:
            example=pd.DataFrame({'synthetic_participant_id':['SYN%04d'%i for i in range(n)],
                'data_kind':'SYNTHETIC_FAIR_COIN_NOT_PLATFORM_USERS','train_n':nt,'validation_n':nv,'test_n':ns,
                'train_win_rate':tr,'validation_win_rate':va,'test_win_rate':te,
                'train_pnl':(tr-0.5)*nt,'test_pnl':(te-0.5)*ns,'selected_using_training':np.isin(np.arange(n),chosen)})
    r=pd.DataFrame(records); summaries={}
    for c in r.columns[1:]:
        summaries[c]={'mean':float(r[c].mean()),'scenario_2_5_percentile':float(r[c].quantile(.025)),
                      'scenario_97_5_percentile':float(r[c].quantile(.975)),
                      'monte_carlo_standard_error':float(r[c].std(ddof=1)/np.sqrt(repetitions))}
    return r,example,{'data_kind':'SYNTHETIC_NULL_ONLY','participants_per_repetition':n,'trials':trials,
        'train_trials':nt,'validation_trials':nv,'test_trials':ns,'repetitions':repetitions,'selected_count':50,
        'true_win_probability':0.5,'true_skill':0,'summaries':summaries}

def evaluate():
    selected=json.loads((OUT/'Selected_Model.json').read_text())
    assert selected['design_sha256']==hashlib.sha256((ROOT/'Research_Design.json').read_bytes()).hexdigest()
    assert selected['development_data_sha256']==hashlib.sha256((OUT/'Historical_Data.csv').read_bytes()).hexdigest()
    d=assign_splits(read_data()); a=selected['shrinkage']
    d['p_adjusted']=(1-a)*d.p_market+a*0.5
    forecast=[]; differences=[]
    models={'market':'p_market','validation_selected_shrinkage':'p_adjusted',
            'constant_0.5':0.5,'training_only_base_rate':selected['training_event_rate']}
    for split in ['train','validation','test','all_descriptive']:
        z=d if split=='all_descriptive' else d[d.split==split]
        if z.empty:continue
        for name,col in models.items():
            p=z[col].to_numpy() if isinstance(col,str) else np.full(len(z),col)
            for metric,v in metric_values(z.y,p).items():
                forecast.append({'split':split,'model':name,'metric':metric,'markets':len(z),**cluster_interval(z,v)})
        if split=='test':
            baseline=(z.p_market.to_numpy()-z.y.to_numpy())**2
            for name,col in models.items():
                if name=='market':continue
                p=z[col].to_numpy() if isinstance(col,str) else np.full(len(z),col)
                delta=baseline-(p-z.y.to_numpy())**2
                differences.append({'model':name,'definition':'market Brier minus alternative Brier; positive favors alternative',
                                    **cluster_interval(z,delta),'exploratory_cluster_sign_flip_p':sign_flip_p(z,delta)})
    # Holm adjustment on the prespecified three held-out Brier comparisons.
    valid=[(i,v['exploratory_cluster_sign_flip_p']) for i,v in enumerate(differences) if v['exploratory_cluster_sign_flip_p'] is not None]
    previous=0.0
    for rank,(i,p) in enumerate(sorted(valid,key=lambda x:x[1])):
        previous=max(previous,min(1.0,p*(len(valid)-rank)))
        differences[i]['holm_adjusted_p']=previous
    pd.DataFrame(forecast).to_csv(OUT/'Forecast_Metrics.csv',index=False)
    save('Paired_Test_Comparisons.json',differences)
    calibration=[]; cats=[]
    for cat,z in [('All',d),*list(d.groupby('category'))]:
        vals=metric_values(z.y,z.p_market)
        cats.append({'category':cat,'markets':len(z),'event_clusters':z.event_cluster.nunique(),
            'archive_chapters':z.chapter.nunique(),'brier':float(vals['brier'].mean()),'log_loss':float(vals['log_loss'].mean()),
            'accuracy':float(vals['accuracy'].mean()),'mean_probability':float(z.p_market.mean()),'observed_frequency':float(z.y.mean()),
            'mean_spread':float(z.anchor_spread.mean()),**{k:v for k,v in cluster_interval(z,vals['brier']).items() if k!='estimate'}})
        bins=np.minimum((z.p_market.to_numpy()*10).astype(int),9)
        for b in range(10):
            w=z.iloc[np.where(bins==b)[0]]
            if w.empty:continue
            calibration.append({'category':cat,'bin':b,'markets':len(w),'mean_probability':float(w.p_market.mean()),
                                'observed_frequency':float(w.y.mean()),**cluster_interval(w,w.y)})
    pd.DataFrame(cats).to_csv(OUT/'Category_Metrics.csv',index=False)
    pd.DataFrame(calibration).to_csv(OUT/'Calibration.csv',index=False)
    q=pd.read_csv(OUT/'Historical_Execution_Quotes.csv');q['split']=q.market_id.map(d.set_index('market_id').split)
    q['resolved_at']=pd.to_datetime(q.resolved_at,utc=True,format='ISO8601')
    scenarios=[]
    for delay in [0,30,60,300,900]:
        for cost in [0,0.005,0.01,0.02,0.05]:
            rows,skip=simulate(q,cost,delay)
            scenarios.append(simulation_summary(rows,skip,cost,delay))
            test_rows=rows[rows.split=='test'];test_skip=skip[skip.split=='test']
            scenarios.append(simulation_summary(test_rows,test_skip,cost,delay,'test'))
    primary,skip=simulate(q)
    primary.to_csv(OUT/'Paper_Positions.csv',index=False)
    pd.DataFrame([{'category':cat,**simulation_summary(rows,skip[skip.category==cat],.01,0)}
                  for cat,rows in primary.groupby('category')]).to_csv(OUT/'Paper_Category_Metrics.csv',index=False)
    skip[['market_id','event_cluster','category','requested_delay_seconds','skip_reason']].to_csv(OUT/'Paper_Skips.csv',index=False)
    pd.DataFrame(scenarios).to_csv(OUT/'Cost_Delay_Sensitivity.csv',index=False)
    # Quote matched-pair comparisons avoid treating a changed survivor cohort as a latency effect.
    delay_pairs=[]
    for delay in [30,60,300,900]:
        later,_=simulate(q,delay=delay)
        z=primary[['market_id','event_cluster','net_pnl']].merge(later[['market_id','net_pnl']],on='market_id',suffixes=('_now','_later'))
        if len(z):delay_pairs.append({'delay':delay,'matched_markets':len(z),
            'meaning':'later net P&L minus anchor net P&L on the same markets',**cluster_interval(z,z.net_pnl_later-z.net_pnl_now)})
    save('Matched_Delay_Comparisons.json',delay_pairs)
    robustness=[]
    if len(primary):
        broad=cluster_interval(primary,primary.net_pnl,cluster='chapter')
        robustness.append({'check':'resample_whole_archive_chapters','mean_net_pnl_per_share':broad['estimate'],
            'ci_low':broad['ci_low'],'ci_high':broad['ci_high'],'chapters':broad['clusters'],
            'note':'exploratory dependence sensitivity; few provider-selected chapter blocks'})
    for frac in [0.5,0.6,0.7]:
        z=assign_splits(read_data(),frac,0.2);v=z[z.split=='validation'];t=z[z.split=='test']
        scores=[(float(np.mean(((1-a)*v.p_market+a*0.5-v.y)**2)),a) for a in [0,.25,.5]]
        alpha=min(scores)[1]
        robustness.append({'check':'alternative_group_time_split','train_fraction':frac,'test_markets':len(t),
            'test_clusters':t.event_cluster.nunique(),'chosen_shrinkage':alpha,
            'test_market_brier':float(np.mean((t.p_market-t.y)**2)),
            'test_adjusted_brier':float(np.mean(((1-alpha)*t.p_market+alpha*0.5-t.y)**2)),
            'interpretation':'exploratory after primary holdout; no independent new test'})
    for limit in [0.1,0.2,1.0]:
        rows,sk=simulate(q,spread_limit=limit)
        robustness.append({'check':'spread_gate','spread_limit':limit,**simulation_summary(rows,sk,.01,0)})
    for count in [1,5,10]:
        rows=primary.sort_values('net_pnl',ascending=False).iloc[count:]
        robustness.append({'check':'remove_largest_positive_contributions','removed':count,
                           'remaining_net_pnl':float(rows.net_pnl.sum()),'remaining_markets':len(rows)})
    for minimum in [5,20,50]:
        counts=d[d.split=='train'].groupby('category').size();eligible=counts[counts>=minimum].index
        z=d[(d.split=='test')&d.category.isin(eligible)]
        robustness.append({'check':'minimum_training_category_observations','minimum':minimum,'test_markets':len(z),
            'test_brier':float(np.mean((z.p_market-z.y)**2)) if len(z) else None,
            'note':'category support diagnostic, not participant selection'})
    for name,mask in [('exclude_reference_extremes',d.p_market.between(.05,.95)),('spread_at_most_0.1',d.anchor_spread<=.1)]:
        z=d[mask]
        robustness.append({'check':name,'markets':len(z),'brier':float(np.mean((z.p_market-z.y)**2)),
                           'note':'full-sample descriptive sensitivity'})
    save('Robustness.json',robustness)
    syn,example,syn_summary=synthetic_experiment()
    syn.to_csv(OUT/'Synthetic_Selection_Replications.csv',index=False)
    example.to_csv(OUT/'Synthetic_Participant_Example.csv',index=False)
    save('Synthetic_Selection_Summary.json',syn_summary)
    syn_sensitivity=[]
    for fraction in [.4,.5,.6,.7]:
        for min_n in [20,80,130]:
            try:
                _,_,s=synthetic_experiment(fraction,min_n,repetitions=100)
                syn_sensitivity.append({'train_fraction':fraction,'min_training_n':min_n,
                    'status':'supported synthetic scenario','train_selected_rate':s['summaries']['selected_train_win_rate']['mean'],
                    'test_selected_rate':s['summaries']['selected_test_win_rate']['mean']})
            except ValueError:
                syn_sensitivity.append({'train_fraction':fraction,'min_training_n':min_n,'status':'insufficient synthetic observations'})
    save('Synthetic_Sensitivity.json',syn_sensitivity)
    counts=d.groupby('split').agg(markets=('market_id','size'),event_clusters=('event_cluster','nunique'),
        earliest_forecast=('anchor_time','min'),latest_resolution=('resolved_at','max')).reset_index()
    counts.to_csv(OUT/'Split_Summary.csv',index=False)
    d.to_csv(OUT/'Forecast_Observations.csv',index=False)
    summary={'data_summary':json.loads((OUT/'Data_Summary.json').read_text()), 'selected_model':selected,
        'split_counts':counts.astype({'earliest_forecast':str,'latest_resolution':str}).to_dict('records'),
        'forecast_metrics':forecast,'test_brier_comparisons':differences,'categories':cats,
        'primary_paper_benchmark':simulation_summary(primary,skip,.01,0),
        'primary_test_paper_benchmark':simulation_summary(primary[primary.split=='test'],skip[skip.split=='test'],.01,0,'test'),
        'matched_delay_comparisons':delay_pairs,'synthetic_null':syn_summary,
        'central_conclusion':'Participant persistence and copied advantage are unidentifiable from these data; market and synthetic results do not establish or refute trader skill.'}
    save('Results.json',summary)
    marker=OUT/'First_Test_Evaluation.json'
    if not marker.exists():
        save(marker.name,{'evaluated_at_utc':datetime.now(timezone.utc).isoformat(),
            'selected_model_sha256':hashlib.sha256((OUT/'Selected_Model.json').read_bytes()).hexdigest(),
            'design_sha256':selected['design_sha256'],'test_markets':int((d.split=='test').sum()),
            'parameters_changed_after_test':False})
    print(json.dumps(clean_json({'split_counts':summary['split_counts'],'selected_shrinkage':a,
        'primary_paper':summary['primary_paper_benchmark'],'test_comparisons':differences,
        'synthetic_selected_train_rate':syn_summary['summaries']['selected_train_win_rate']['mean'],
        'synthetic_selected_test_rate':syn_summary['summaries']['selected_test_win_rate']['mean']}),indent=2))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['develop','evaluate'])
    args=parser.parse_args()
    develop() if args.stage=='develop' else evaluate()
