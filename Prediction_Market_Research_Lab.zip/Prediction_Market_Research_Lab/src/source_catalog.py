"""Inventory inspected sources and failed requests; never represent inaccessible papers as read."""
import hashlib
import json
from pathlib import Path
import re
import csv
import html
from urllib.parse import urlencode

ROOT=Path(__file__).resolve().parents[1]
RAW=ROOT/'sources/raw'; OUT=ROOT/'deliverables'
B='https://raw.githubusercontent.com/'
M='marketlenstrade/polymarket-historical-data/6eb9b8efda545eddafb2a8f75acb4bcbca6db019/'
J='Jon-Becker/prediction-market-analysis/9afe7a1cb8fd5acb207fb01027d6114a414f0cd2/'
ROWS=[
('S01','Marketlens historical archive README',B+M+'README.md','free_data_readme.txt','Third-party dataset provider','Coverage and collection claims; no independent exchange verification.'),
('S02','Marketlens archive manifest',B+M+'manifest.json','manifest.json','Third-party dataset manifest','Exact file hashes, reported counts and date windows; all history hashes checked.'),
('S03','Marketlens collection/export source',B+M+'tools/build.py','tools__build.py','Third-party collection code','Resolved-only sample selection, book export, snapshot subsampling and settlement metadata provenance.'),
('S04','Marketlens data license',B+M+'LICENSE','LICENSE','Dataset license','CC BY 4.0; attribution: Marketlens, https://marketlens.trade.'),
('S05','Marketlens citation metadata',B+M+'CITATION.cff','CITATION.cff','Dataset citation metadata','Dataset author and citation details.'),
('S06','Historical Polymarket CTF exchange overview',B+'Polymarket/ctf-exchange/main/docs/Overview.md','poly_exchange_overview.txt','Primary platform technical source, archived','Off-chain matching and on-chain settlement; mint/merge mechanics; signed fee terms. Not a dated platform-wide fee schedule.'),
('S07','Archived Polymarket CLOB client README',B+'Polymarket/py-clob-client/main/README.md','poly_sdk.txt','Primary platform technical source, archived','Read-only market interfaces versus authenticated functions; explicit warning that this SDK is no longer functional.'),
('S08','Current Polymarket Python SDK README',B+'Polymarket/py-sdk/main/README.md','poly_sdk_new.txt','Primary platform technical source','Migration destination, evolving API surface. Not installed or used to trade.'),
('S09','Kalshi official Python starter README',B+'Kalshi/kalshi-starter-code-python/main/README.md','kalshi_official_readme','Primary platform technical source','Example for authenticated endpoints; not evidence of public account ledgers.'),
('S10','Kalshi official starter client source',B+'Kalshi/kalshi-starter-code-python/main/clients.py','kalshi_client_source.txt','Primary platform client code','Signed authentication and portfolio/market routes. Client code alone does not establish all public endpoint permissions.'),
('S11','Kalshi community analysis repository README',B+'Kalshi/tools-and-analysis/main/README.md','kalshi_tools_readme','Officially hosted community work','Forecast visualization examples; notebooks depend on authenticated historical retrieval, not a shipped transaction dataset.'),
('S12','Becker research framework README',B+'Jon-Becker/prediction-market-analysis/main/README.md','data_repo_readme.txt','Independent research repository','Documents 36 GiB compressed external archive and a bibliography. Largest-dataset claim not independently verified.'),
('S13','Becker market/trade schemas',B+'Jon-Becker/prediction-market-analysis/main/docs/SCHEMAS.md','becker_schemas.txt','Independent collector documentation','Kalshi tape lacks participant IDs; Polymarket fills expose on-chain roles and amounts but require token/time/redemption joins.'),
('S14','Becker Kalshi maker/taker analysis code',B+J+'src/analysis/kalshi/maker_vs_taker_returns.py','becker_maker_analysis.txt','Independent analytical code','Role-level settlement-P&L construction; role aggregates are not individual participant persistence.'),
('S15','Becker Polymarket calibration code',B+J+'src/analysis/polymarket/polymarket_calibration_by_bucket.py','becker_calibration.txt','Independent analytical code','Trade-weighted calibration and bucket-approximate Brier; repeated-event dependence remains a research design issue.'),
('S16','Becker statistical analysis code',B+J+'src/analysis/kalshi/statistical_tests.py','becker_statistical_tests.txt','Independent analytical code','Some comparisons count contracts in proportions; audit independence and multiplicity before interpreting significance. Not rerun without data.'),
('S17','Open-source copying project README',B+'shmlkv/polymarket-copy-trading-bot/main/README.md','copy_claim_1.txt','Promotional/self-authored project description','Claims of copying best traders and immediate execution; dashboard images do not supply an audited follower ledger.'),
('S18','Prediction-market toolkits README',B+'HarrierOnChain/Prediction-Markets-Trading-Bot-Toolkits/main/README.md','copy_claim_2.txt','Promotional/self-authored project description','Explicitly describes hosted copying beta as paper trading, closed, and never touching real funds. Not verified earned profits.'),
('S19','Polymarket copy-research README',B+'artym359/polymarket-copy-research/main/README.md','copy_research.txt','Independent methodological repository','Documents lifecycle sizing, proxy prices, look-ahead hazards, missing equity curves, and missing public raw histories. No independently reproducible success proof.'),
('S20','Polymarket historical price collector README',B+'LuciferForge/polymarket-historical-data/main/README.md','lucifer_data_readme.txt','Dataset vendor/self-report','Admits no resolution labels and mostly placeholder order books; claims live results but no independent audit completed here.'),
('S21','Earlier historical price-sample README',B+'manja316/polymarket-historical-data/main/README.md','manja_data_readme.txt','Dataset vendor/self-report','Advertises price snapshots, backtest results and paid complete data. Distinguish previews, modeled results and realized execution.'),
('S22','Crash-recovery project README',B+'LuciferForge/polymarket-crash-bot/main/README.md','crash_claim.txt','Self-reported strategy results, not copying','280 trades, 80.4% claimed win rate in this README; related README claims 302/79.8%. Different snapshots/definitions cannot be reconciled from summaries.'),
('S23','GitHub repository search: copying', 'https://github.com/search?q=polymarket+copy+trading&type=repositories','github_search.txt','Search result, not performance evidence','Discovery only. Search rankings and star counts do not verify profitability.'),
('S24','GitHub repository search: historical data','https://github.com/search?q=polymarket+historical+data&type=repositories','search_polymarket_historical_data.txt','Search result, not dataset validation','Discovery of archives, collectors and vendor samples.'),
('S25','Archived Polymarket CTF exchange README',B+'Polymarket/ctf-exchange/main/README.md','poly_contract.txt','Primary platform technical source, archived','Explicit archive warning and V2 replacement destination; not a verified historical fee schedule.'),
('S26','Becker framework software license',B+'Jon-Becker/prediction-market-analysis/main/LICENSE','becker_license.txt','Software license','MIT software license; do not infer independent data redistribution rights.'),
('S27','Kalshi community Oscars notebook',B+'Kalshi/tools-and-analysis/main/projects/oscars_2023/main.ipynb','kalshi_oscars_notebook.txt','Officially hosted community notebook','Inspected code/outputs; uses authenticated historical calls, not a shipped participant panel.'),
('S28','Kalshi community rate-market notebook',B+'Kalshi/tools-and-analysis/main/projects/fed_feb_2023/main.ipynb','kalshi_fed_notebook.txt','Officially hosted community notebook','Inspected code/outputs; no recovered raw historical market or participant ledger.'),
]
BLOCKED=[
('N01','Polymarket documentation','https://docs.polymarket.com/llms.txt'),
('N02','Kalshi documentation','https://docs.kalshi.com/llms.txt'),
('N03','GitHub REST metadata','https://api.github.com/repos/Jon-Becker/prediction-market-analysis'),
('N04','Academic search','https://arxiv.org/search/?query=polymarket&searchtype=all'),
('N05','Reddit copying discussion search','https://www.reddit.com/search.json?q=polymarket%20copy%20trading&limit=10'),
('N06','Polymarket settled market metadata','https://gamma-api.polymarket.com/markets?limit=2&closed=true&end_date_max=2025-01-01T00%3A00%3A00Z'),
('N07','Kalshi settled markets','https://api.elections.kalshi.com/trade-api/v2/markets?limit=2&status=settled'),
('N08','Broad web search','https://www.google.com/search?q=polymarket+copy+trading+profit+research')
]
DISCOVERY=[
('org:Polymarket docs','repositories','search_org_Polymarket_docs.txt'),
('org:Kalshi docs','repositories','search_org_Kalshi_docs.txt'),
('kalshi historical dataset','repositories','search_kalshi_historical_dataset.txt'),
('polymarket calibration skill','repositories','search_polymarket_calibration_skill.txt'),
('org:Kalshi','repositories','kalshi_repos.txt'),
('polymarket paper arbitrage','repositories','search_polymarket_paper_arbitrage.txt'),
('prediction markets trader skill research','repositories','search_prediction_markets_trader_skill_research.txt'),
('repo:shmlkv/polymarket-copy-trading-bot loss','issues','search_repo_shmlkv_polymarket_copy_trading_bot_loss.txt'),
('repo:HarrierOnChain/Prediction-Markets-Trading-Bot-Toolkits loss','issues','search_repo_HarrierOnChain_Prediction_Markets_Trading_Bot_Toolkits_loss.txt')
]

def build():
    records=[]
    for sid,title,url,file,kind,use in ROWS:
        p=RAW/file
        if not p.exists():raise FileNotFoundError(file)
        original=p.read_bytes()
        # Redact public example wallet addresses; no wallet directory is distributed.
        redacted=re.sub(rb'0x[a-fA-F0-9]{40,64}',b'[REDACTED_ADDRESS_OR_HASH]',original)
        if redacted!=original:p.write_bytes(redacted)
        records.append({'id':sid,'title':title,'url':url,'access_date':'2026-10-14',
            'status':'inspected','type':kind,'use_and_limit':use,
            'cached_body_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'cached_bytes':p.stat().st_size,
            'redacted_examples':b'[REDACTED_ADDRESS_OR_HASH]' in p.read_bytes()})
    for sid,title,url in BLOCKED:
        records.append({'id':sid,'title':title,'url':url,'access_date':'2026-10-14',
            'status':'blocked_network_policy_403_connect','use_and_limit':'No content read; not evidence for factual claims.'})
    (OUT/'Source_Manifest.json').write_text(json.dumps(records,indent=2))
    lines=['# Sources and access audit','',
        'Research date: October 14, 2026. All access dates below are 2026-10-14. Source content was retrieved by HTTPS using local research tools. No general browser/search connector was available; public GitHub search pages and raw files were inspected. The proxy blocked the destinations listed below. No Reddit thread, academic full text, official API settlement response, or current fee schedule is represented as inspected. Text hashes identify the inspected cache after redacting public wallet/address examples; they are not claims of an unmodified upstream response. Source dataset Parquet hashes are checked separately against the original provider manifest.',
        '', '## Inspected sources','']
    for v in records:
        if v['status']!='inspected':continue
        lines += [f"### [{v['id']}] {v['title']}",f"- URL: {v['url']}",
                  f"- Type: {v['type']}",f"- Use and limit: {v['use_and_limit']}",
                  f"- Inspected cached-text SHA-256: `{v['cached_body_sha256']}`",'']
    lines += ['## Blocked requests (not read)','']
    for v in records:
        if v['status']=='inspected':continue
        lines += [f"- [{v['id']}] {v['title']}: {v['url']} — proxy CONNECT 403 Forbidden."]
    lines += ['', '## Additional discovered literature — bibliographic leads only','',
        'The following titles and links appeared in the inspected Becker README [S12]. Full papers, authorship details, revisions, peer-review status and numerical findings were not independently verified. They are leads for completing the blocked literature review, not support for this report’s findings.', '',
        '- Reichenbach and Walther, *Exploring Decentralized Prediction Markets: Accuracy, Skill, and Bias on Polymarket* (listed as 2025): https://papers.ssrn.com/sol3/papers.cfm?abstract_id=5910522',
        '- Akey et al., *Who Wins and Who Loses In Prediction Markets? Evidence from Polymarket* (listed as 2026): https://papers.ssrn.com/sol3/papers.cfm?abstract_id=6443103',
        '- Luong and Heesen, *The Wisdom of the Few: Skilled Traders and Prediction Market Accuracy* (listed as 2026): https://papers.ssrn.com/sol3/papers.cfm?abstract_id=6758662',
        '- Bartlett and O’Hara, *Adverse Selection in Prediction Markets: Evidence from Kalshi* (listed as 2026): https://papers.ssrn.com/sol3/papers.cfm?abstract_id=6615739',
        '- Cardozo and Rivero-Wildemauwe, *The Favorite-Longshot Bias in Prediction Markets: Evidence from Polymarket* (listed as 2026): https://arxiv.org/abs/2609.12878',
        '', '## Data attribution and redistribution','',
        'Historical records are derived from Marketlens, https://marketlens.trade, *Polymarket Historical Data*, pinned Git commit `6eb9b8efda545eddafb2a8f75acb4bcbca6db019`. Original source: https://github.com/marketlenstrade/polymarket-historical-data. The provider releases data under CC BY 4.0 [S04]; license text is included as `Data_License.txt`. Changes: selected binary settled markets, excluded overlapping crypto cadences and unusable records, normalized first-outcome labels, extracted top quote sizes, grouped related events, and computed offline metrics. No platform endorsement is implied.',
        '', 'The Becker framework is MIT-licensed, but its external data archive was not downloaded or redistributed. Do not infer all platform data rights from a software license. Other vendor price samples were assessed from documentation only and are not redistributed.',
        '', '## Network configuration saved','',
        'A draft adds docs.polymarket.com, docs.kalshi.com, gamma-api.polymarket.com, clob.polymarket.com, api.elections.kalshi.com, api.github.com, arxiv.org, export.arxiv.org, www.reddit.com, www.google.com, s3.jbecker.dev, and papers.ssrn.com. Package-manager presets were preserved. Draft save was confirmed; these additions were not applied to or tested in a newly published environment. To extend the blocked research, review and save settings, then publish the environment and recheck access. No account keys are needed for the supplied offline lab.', '']
    discovery=[]
    for query,kind,filename in DISCOVERY:
        content=(RAW/filename).read_text();count=None
        for raw in re.findall(r'<script[^>]*type="application/json"[^>]*>(.*?)</script>',content,re.S):
            try:
                route=json.loads(html.unescape(raw)).get('payload',{}).get('blackbirdSearchRoute',{})
                if 'results' in route:count=route.get('result_count')
            except (ValueError,TypeError):pass
        discovery.append({'query':query,'type':kind,'url':'https://github.com/search?'+urlencode({'q':query,'type':kind}),
                          'access_date':'2026-10-14','reported_result_count':count,
                          'limit':'Discovery only; result count/rank is not performance evidence or proof of dataset absence.'})
    with (OUT/'Discovery_Search_Log.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(discovery[0]));writer.writeheader();writer.writerows(discovery)
    lines += ['## Additional discovery requests','',
              'These queries supplement the 28 cataloged source entries. A zero-result query does not establish that relevant data or research does not exist. All were accessed on 2026-10-14; no contributor identities or candidate wallets are published.','']
    for d in discovery:lines.append(f"- {d['query']} ({d['type']}): {d['url']} — GitHub-reported results: {d['reported_result_count']}.")
    lines += ['', 'Additional inspected archive paths and pages (all 2026-10-14):','',
              '- https://github.com/marketlenstrade/polymarket-historical-data — root directory/file discovery.',
              '- https://codeload.github.com/marketlenstrade/polymarket-historical-data/tar.gz/6eb9b8efda545eddafb2a8f75acb4bcbca6db019 — complete acquired source archive.',
              '- https://codeload.github.com/Jon-Becker/prediction-market-analysis/tar.gz/refs/heads/main — research code archive, not the external 36 GiB dataset.',
              '- https://codeload.github.com/Kalshi/tools-and-analysis/tar.gz/refs/heads/main — inspected notebook/code archive.',
              '- https://raw.githubusercontent.com/marketlenstrade/polymarket-historical-data/main/targets.json — event selection definitions.',
              '- https://raw.githubusercontent.com/marketlenstrade/polymarket-historical-data/main/apple-weekly-2026-06-12/markets.csv — initial metadata inspection.',
              '- https://raw.githubusercontent.com/marketlenstrade/polymarket-historical-data/main/apple-weekly-2026-06-12/snapshots.csv — initial reference quote inspection, not used as full-depth execution data.',
              '- https://raw.githubusercontent.com/marketlenstrade/polymarket-historical-data/main/nyc-weather-2026-07-16/markets.csv — initial metadata inspection.',
              '- https://raw.githubusercontent.com/marketlenstrade/polymarket-historical-data/main/ufc-330-2026-08-16/markets.csv — initial metadata inspection.',
              '- https://raw.githubusercontent.com/marketlenstrade/polymarket-historical-data/main/bitcoin-5m-15m-hourly-2026-06-15/markets.csv — initial metadata inspection.',
              '', 'Failed path-discovery requests (HTTP 404; not inspected sources and not proof a platform has no SDK):','',
              '- https://raw.githubusercontent.com/Polymarket/docs/main/README.md',
              '- https://raw.githubusercontent.com/Kalshi/kalshi-python/master/README.md',
              '- https://raw.githubusercontent.com/Kalshi/kalshi-python/main/README.md',
              '- https://raw.githubusercontent.com/Kalshi/kalshi-starter-code/main/README.md','']
    (OUT/'Sources.md').write_text('\n'.join(lines))
    # Keep the original license, unmodified, as required by attribution terms.
    (OUT/'Data_License.txt').write_bytes((ROOT/'data/raw_marketlens/LICENSE').read_bytes())
    print('Inventoried',len(ROWS),'inspected sources and',len(BLOCKED),'blocked requests.')

if __name__=='__main__':build()
