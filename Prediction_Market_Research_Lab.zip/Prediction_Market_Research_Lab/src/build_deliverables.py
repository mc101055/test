"""Build publication artifacts from the completed, offline analysis."""
from __future__ import annotations
import json
import os
from pathlib import Path
import sys
import html
os.environ.setdefault('MPLCONFIGDIR', str(Path(__file__).resolve().parents[1]/'.cache/matplotlib'))
os.environ.setdefault('XDG_CACHE_HOME', str(Path(__file__).resolve().parents[1]/'.cache'))
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter
from openpyxl.workbook.properties import CalcProperties
import nbformat
from plotly.offline import get_plotlyjs
from analysis import clean_json

ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'deliverables'; CHARTS=OUT/'charts'

def md_table(headers, rows):
    def cell(x):return str(x).replace('|','/').replace('\n',' ')
    return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+
                     ['| '+' | '.join(cell(v) for v in row)+' |' for row in rows])

PLATFORMS=[
('Participant linkage','Potential pseudonymous linkage in on-chain fill fields; address is not person [S06,S13].','No participant IDs in the inspected public trade schema [S13].','Actual longitudinal participant histories not acquired for either platform.'),
('Market and trade data','Public interfaces/collector schemas documented; this lab uses a third-party archive [S07,S13].','Anonymous prices/quantities/time schema documented [S13]; official API access blocked.','Only Polymarket archive counts and internal consistency verified.'),
('Historical order books','Available if contemporaneously archived; provider supplies snapshots/compacted events [S01,S03].','No historical L2 archive acquired.','Polymarket recorded price/depth checked; actual fills not verified.'),
('Settlement','Provider winner/time labels available; token redemption joins needed for independent on-chain accounting.','Result fields documented in collector schema; no official response acquired.','Zero settlements independently verified in this session.'),
('Leaderboards','A displayed historical profit total omits cohort selection, full exposure and follower prices.','Optional leaderboard/profile content and definitions not verified here.','No examined leaderboard establishes audited copying performance.'),
('Fees and historical changes','Archived contract fee mechanics inspected; effective 2026 schedules unavailable [S06,S07].','Effective-dated schedule unavailable.','Additional modeled costs are hypothetical; neither platform assumed fee-free.'),
('Spread and liquidity','Bid/ask and best-level sizes in acquired archive; conditional quote-taking only.','No numerical spread/liquidity sample acquired.','Actual queue fills, minimum order constraints and impact unsupported.'),
('Position-level P&L','Requires complete fills, mappings, transfers, mint/merge/redemption, rewards and open-position marks.','Anonymous tape cannot link participant portfolios; authenticated portfolio route exists [S10,S13].','Observed realized/unrealized trader P&L unmeasured.'),
('Making versus direction','Fill roles can inform classification; same address may change roles and hedge.','Trade-side/role aggregates possible from schema; participant classification unavailable.','Maker aggregate profitability is not evidence of copied forecasting skill.'),
('Capital and external hedges','On-chain cash alone does not reveal other accounts or venues.','No participant cash/portfolio ledger acquired.','True capital ROI and complete economic hedges cannot be verified.')
]
CLAIMS=[
('Copying README [S17]','Copies top traders; every-second monitoring and instant execution; dashboard images.','Self-authored claims and images, not an independently reconciled ledger.','No verified follower profit or untouched test found in inspected content.'),
('Toolkits README [S18]','Wallets described as having proven alpha; several execution/arb mechanisms.','Hosted service explicitly paper-only, closed, never touched real funds.','Do not classify the hosted demonstration as earned profit.'),
('Copy research [S19]','Lifecycle reconstruction and sensitivity tools.','Raw histories excluded; proxy-fill and biased-exit warnings; baseline comparison out of scope.','Useful methods; no performance replication completed from a public user panel.'),
('Crash project [S22]','280 claimed live trades; 80.4% wins; 6,225 backtested trades/75%.','Self-report; not a copy strategy; summary does not reconcile fills, fees or capital.','Unverified results; high win rate alone not proof of profitable copying.'),
('Related vendor archive [S20]','302 claimed trades, 79.8% wins; dense price archive.','Different summary version; admits no settlement labels and mostly placeholder books.','Claim difference unresolved; cannot score outcomes or reconstruct follower P&L from that archive alone.')
]
DATASETS=[
('Marketlens archive [S01–S05]','Selected June–September 2026 windows; 2,278 markets / 17,317,874 event rows.','No participants; snapshots, compact deltas, trades, provider settlements.','CC BY 4.0. All history hashes/counts checked; exchange authenticity and settlement not corroborated.'),
('Cleaned archive in this lab','2,021 binary markets / 171 event groups; 10,105 delay records.','One market-reference forecast per market plus snapshot-level top prices/sizes.','Derived CC BY 4.0 data; first captured book can be in-play; selected settled/quoted cohort.'),
('Becker combined archive candidate [S12–S16]','36 GiB compressed archive documented; record count/date range not independently checked.','Kalshi schema lacks participants; Polymarket on-chain role addresses in raw schema.','Software MIT. External data not acquired; do not infer dataset rights or numerical conclusions from code.'),
('Vendor price archive [S20–S21]','Vendor reports 18.6M prices/22,410 markets for Mar–Jun 2026; not independently counted.','Reference snapshots; provider admits no resolution labels, mostly placeholder books.','Documentation assessed only; paid complete export not purchased or analyzed.'),
('Kalshi community notebooks [S11]','2023 Oscars/rate-market examples; not a shipped transaction dataset.','Code/figures, authenticated historical calls; no reconstructable participant ledger.','Officially hosted community examples; numeric historical dataset not recovered.'),
('Synthetic null panel','250 repetitions × 1,000 simulated participants × 200 fair trials.','Explicit hypothetical IDs, no platform users; training/validation/test results.','Generated by this lab; no real earnings, histories or market trades implied.')
]
EXPERIMENTS=[
('A: historical success persistence','Unsupported for observed participants.','No linked participant panel or complete P&L/capital histories.'),
('B: participant forecasting information','Unsupported.','No participant forecasts or actions to compare with market prices. Market-only forecast diagnostic is separate.'),
('C: selection bias','Supported, synthetic only.','Known zero-skill population; training-only and forbidden test-selected groups contrasted.'),
('D: observation delay','Supported conditionally at archived snapshots.','First later snapshot, explicit waits, quote/size gates, matched cohort; no actual copied orders.'),
('E: market categories','Descriptive support only.','Seven selected category chapters, very few independent events in some categories; politics absent.'),
('F: costs','Supported hypothetical sensitivity.','Recorded asks plus declared extra-cost scenarios; actual fee histories unavailable.')
]
BIAS=[
('Survivorship bias','Visible profitable survivors omit inactive or failed participants; their cohort average is upward-selected.','Need a timestamped cohort including non-survivors. This archive cannot measure user attrition.'),
('Look-ahead bias','A later winner, settlement label or future entry can influence an earlier selection or sizing decision.','Purged time split and frozen model; [S19] specifically warns against allocating an initial budget over future buys.'),
('Selection/publication bias','Strongest accounts, markets, intervals and screenshots are shown while losing attempts remain unseen.','No denominator of all public attempts. The synthetic oracle attains 66.21% with zero skill by selecting on test outcomes.'),
('Overfitting/multiple testing','Trying many thresholds or cohorts finds attractive noise; a lone reported p-value omits that search.','Prespecified three shrinkages; validation choice frozen; Holm for three test comparisons only. Further filters are exploratory.'),
('Delayed information','The follower learns only after an execution or disclosure, when prices and availability may have changed.','Matched snapshot pairs show worse asks on average here; requested and effective delays are reported separately.'),
('Transaction fees/incentives','Ignoring charged fees or using a maker rebate for a taker inflates copied net results; historical schedules can differ.','No verified effective-dated schedules. All extra costs are labeled hypothetical; rebates not invented.'),
('Bid–ask spread','Midpoint fills give the follower a price not normally available to a liquidity taker.','Same modeled positions lose $4.97 at midpoints versus $44.95 at asks, before extra modeled costs.'),
('Market impact','Scaling the leader’s trade can consume best-level depth and worsen later fills.','Only a one-share conditional model, checked against best-ask size; no assertion of scalable execution.'),
('Slippage/quote staleness','Last prints or old books can be mistaken for currently attainable prices.','No stale pre-target fill. A 300-second additional-wait cap limits, but does not eliminate, snapshot uncertainty.'),
('Illiquidity/partial fills','Empty books, minimum order sizes and queue position prevent a modeled entry from actually completing.','Empty books excluded; depth/spread skips preserved. Actual fill/minimum-dollar compliance remains unverified.'),
('Incomplete position histories','Missing older inventory, sells or redemptions turn turnover or open P&L into an erroneous profit estimate.','No observed portfolio reconstruction attempted. Public-data repository [S19] acknowledges history/pagination limitations.'),
('Hidden hedging','A visible winning leg can be offset by a losing position on another account or venue.','Need linked economic exposures. This is a conceptual limitation, not a claim about a specific wallet.'),
('Unobserved deposits/withdrawals','An increase in account value can be funding rather than profit; capital denominators become misleading.','Require reconciled external flows for account returns. Trade-only outlay return is explicitly not capital ROI.'),
('Different entry/exit times','A displayed final position conceals averaging and staged exits; buying once later does not recreate its cost basis.','Benchmark is declared first-outcome buy-and-hold, not a copied lifecycle. [S19] distinguishes lifecycle and proxy exits.'),
('Market making versus direction','Spread capture and inventory netting produce profit without a high forecasting win rate; a follower may pay that spread.','Official exchange mechanics [S06] and role schemas [S13] show why roles matter; actual participant classification unsupported.'),
('Correlated events','Hundreds of props on one match or overlapping horizons repeat the same underlying information and uncertainty.','Group by event, remove longer crypto cadences, purge across periods, resample groups rather than contracts.'),
('Luck versus forecasting skill','The top of a large equally unskilled population looks exceptional by construction.','Synthetic selected training wins 59.33% versus 49.99% test; this is not an estimate of actual trader skill.'),
('Small samples','A few wins or an event jackpot can produce impressive dollar totals with wide uncertainty.','Test has only 93 markets/35 groups on one day; weather three events and equity one. Sparse intervals are flagged.'),
('Misleading ROI','Dollar profit, P&L divided by volume, recycled outlay and return on equity measure different things.','Use explicitly named return on aggregate modeled outlay; no annualization, Sharpe or actual capital ROI.'),
('Resolution/void handling','Assigning ambiguous or refund settlements binary wins/losses, or inferring winners from final prices, corrupts scores.','29 source half/half settlements excluded; provider labels not officially verified; no final-price-as-outcome substitution.'),
('Heterogeneous horizons/category shifts','Near-settlement prices and easy base-rate propositions can make one category look inherently more skillful.','Reference times differ; test entirely esports with no unpurged training esports. Cross-category conclusions are unsupported.')
]

DESCRIPTIONS={
 'market_id':'Provider-assigned market UUID; not an account or wallet identity.',
 'event_cluster':'Deterministic hashed event-group ID; all related contracts grouped for uncertainty and splits.',
 'category':'Broad category assigned by source chapter; one selected chapter per category.',
 'chapter':'Original source folder/event-window identifier.', 'question':'Original public market question; not a trader identifier.',
 'outcome_name':'First named outcome whose probability and payout are normalized.', 'other_outcome_name':'The second binary outcome.',
 'winning_outcome':'Provider-reported winning name; not independently corroborated by official settlement.',
 'y':'Binary payout of first named outcome: 1 if it is the reported winner, otherwise 0.',
 'resolved_at':'Provider-reported settlement timestamp, UTC; also label-availability boundary.',
 'close_time':'Provider-reported closing time, UTC; quote use stops at earlier close/resolution.',
 'anchor_time':'First valid full archived two-sided preclose snapshot, UTC. May be in-play.',
 'anchor_t_ms':'Same anchor as integer milliseconds since Unix epoch.',
 'p_market':'Reference probability (anchor bid+ask)/2; not an executable price or trader forecast.',
 'anchor_spread':'Anchor ask minus bid, dollars per share.', 'source_commit':'Pinned Git commit of public source archive.',
 'data_kind':'third_party_reported_historical; no synthetic or observed participant records in this CSV.',
 'settlement_verification':'provider_label_only; zero independent official label checks in this session.',
 'requested_delay_seconds':'Requested delay from anchor; grid 0,30,60,300,900.',
 'execution_status':'eligible, no_preclose_snapshot_after_delay, or snapshot_wait_exceeds_300s. Eligible is a data gate, not proof of fill.',
 'quote_time':'UTC time of first valid full snapshot at/after delayed target; blank if none exists.',
 'effective_delay_seconds':'Actual quote timestamp minus anchor timestamp.',
 'additional_snapshot_wait_seconds':'Effective delay minus requested delay; eligibility cap 300 seconds.',
 'bid':'Best positive bid of recorded first-outcome book, dollars/share; not a modeled entry.',
 'ask':'Lowest positive ask of recorded first-outcome book, dollars/share; conditional paper entry.',
 'bid_size':'Summed posted shares at best bid price, not total bid-side depth.',
 'ask_size':'Summed posted shares at best ask price; conditional size gate uses this field.',
 'midpoint':'Delayed quote (bid+ask)/2; reference price only.', 'spread':'Delayed quote ask minus bid, dollars/share.',
 'split':'Original event-group period: train, validation, test, purged_train, purged_validation.',
 'quantity':'Exactly one hypothetical share; not a recommended real order size.',
 'gross_pnl':'Hypothetical payout minus ask times quantity; already pays the bid–ask spread.',
 'modeled_cost':'Declared hypothetical additional cost per share times quantity; not verified exchange fees.',
 'net_pnl':'Gross conditional paper P&L less modeled cost, dollars.',
 'outlay':'Ask times quantity plus hypothetical additional cost, dollars.',
 'return_on_outlay':'Net modeled P&L/outlay; not return on participant capital.',
 'skip_reason':'Blank for accepted conditional positions; otherwise records why a quote was not modeled as filled.',
}

def dictionary():
    rows=[]
    for filename in ['Historical_Data.csv','Historical_Execution_Quotes.csv','Paper_Positions.csv']:
        d=pd.read_csv(OUT/filename)
        for c in d:
            if c not in DESCRIPTIONS:raise ValueError('Undocumented field: '+c)
            units=('UTC ISO 8601' if c.endswith('_time') or c=='resolved_at' else
                   'milliseconds UTC epoch' if c=='anchor_t_ms' else
                   'seconds' if 'seconds' in c else
                   'shares' if c in ['quantity','bid_size','ask_size'] else
                   'USD/share or USD' if c in ['bid','ask','anchor_spread','spread','gross_pnl','net_pnl','outlay','modeled_cost'] else
                   '0–1' if c in ['p_market','midpoint','y'] else 'text or dimensionless')
            rows.append({'file':filename,'field':c,'pandas_type':str(d[c].dtype),'units':units,
                         'missing_rows':int(d[c].isna().sum()),'definition_and_limit':DESCRIPTIONS[c]})
    pd.DataFrame(rows).to_csv(OUT/'Data_Dictionary.csv',index=False)
    text='# Data dictionary\n\nThe principal historical files contain no participant identities. Missing delayed quotes are missing execution evidence, never zero-price fills or zero losses. Prices are dollars per share and timestamps use UTC. Outcome labels are third-party reported.\n\n'
    for f in ['Historical_Data.csv','Historical_Execution_Quotes.csv','Paper_Positions.csv']:
        z=[v for v in rows if v['file']==f]
        text+='## '+f+'\n\n'+md_table(['Field','Type / unit','Missing rows','Definition and limitation'],
            [(v['field'],v['pandas_type']+' / '+v['units'],v['missing_rows'],v['definition_and_limit']) for v in z])+'\n\n'
    text+='## Supporting outputs\n\nData_Audit.csv counts raw event/trade/snapshot validation findings by market. Excluded_Observations.csv lists one market-level exclusion reason. Period_Assignments.csv contains original event-group split labels. Forecast_Observations.csv adds the frozen adjustment to the normalized historical data. Forecast_Metrics.csv records score means, event counts and conditional 95% cluster intervals. Calibration.csv contains occupied ten-bin reliability statistics. Category_Metrics.csv and Paper_Category_Metrics.csv are descriptive category aggregates. Paper_Skips.csv preserves nonfills and reasons. Cost_Delay_Sensitivity.csv records all predeclared cost/delay scenarios for full and test cohorts. Matched_Delay_Comparisons.json records same-market later-minus-anchor P&L changes and clustered intervals. Robustness.json records exploratory sensitivity outcomes, including empty prior-category support.\n\nSynthetic_Selection_Replications.csv contains one row per simulated world; its win rates are hypothetical, not observed users. Synthetic_Participant_Example.csv contains a representative zero-skill world with SYN IDs, trial counts, win rates and fair-coin P&L. Synthetic_Selection_Summary.json separates scenario percentiles from Monte Carlo standard errors. Source_Manifest.json contains inspected/blocked URLs, date and content hashes, never credentials. The design, selected-model and initial-test JSON files document frozen choices and evaluation boundaries.\n'
    (OUT/'Data_Dictionary.md').write_text(text)

def charts():
    CHARTS.mkdir(exist_ok=True)
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,
                         'axes.titleweight':'bold','figure.facecolor':'white','axes.grid':True,'grid.alpha':.16})
    def finish(fig,name):
        fig.tight_layout();fig.savefig(CHARTS/(name+'.png'),dpi=180,bbox_inches='tight')
        fig.savefig(CHARTS/(name+'.pdf'),bbox_inches='tight');plt.close(fig)
    cal=pd.read_csv(OUT/'Calibration.csv');z=cal[cal.category=='All']
    fig,ax=plt.subplots(figsize=(7.8,4.5));ax.plot([0,1],[0,1],'--',color='#8795a5',label='Perfect calibration')
    ax.plot(z.mean_probability,z.observed_frequency,'o-',color='#097c71',label='Reported historical outcomes')
    ok=z.ci_low.notna();ax.errorbar(z.loc[ok,'mean_probability'],z.loc[ok,'observed_frequency'],
        yerr=np.vstack([z.loc[ok,'observed_frequency']-z.loc[ok,'ci_low'],z.loc[ok,'ci_high']-z.loc[ok,'observed_frequency']]),fmt='none',color='#097c71',capsize=3)
    ax.set(xlabel='Mean archived midpoint probability',ylabel='Reported first-outcome frequency',title='Market-reference calibration · 2,021 selected markets',xlim=(0,1),ylim=(0,1));ax.legend();finish(fig,'calibration')
    f=pd.read_csv(OUT/'Forecast_Metrics.csv');z=f[(f.split=='test')&(f.metric=='brier')]
    labels=['Market','Validation-selected\nadjustment','Constant 50%','Training-only\nbase rate']
    fig,ax=plt.subplots(figsize=(7.8,4.4));ax.bar(labels,z.estimate,color=['#097c71','#4777ad','#b4bdc7','#df9b59'])
    ax.errorbar(range(len(z)),z.estimate,yerr=[z.estimate-z.ci_low,z.ci_high-z.estimate],fmt='none',color='#25364a',capsize=5)
    ax.set(ylabel='Brier score (lower is better)',title='Held-out forecasts · 93 markets / 35 event groups');finish(fig,'holdout_brier')
    p=pd.read_csv(OUT/'Paper_Positions.csv');g=p.groupby('resolved_at')[['gross_pnl','net_pnl']].sum().sort_index().cumsum()
    fig,ax=plt.subplots(figsize=(7.8,4.4));ax.plot(pd.to_datetime(g.index,utc=True),g.gross_pnl,label='At archived asks, before extra costs',color='#4777ad');ax.plot(pd.to_datetime(g.index,utc=True),g.net_pnl,label='After hypothetical $0.01/share extra cost',color='#b95162');ax.axhline(0,color='#8795a5',lw=1)
    ax.set(ylabel='Cumulative finalized modeled P&L (USD)',title='Conditional one-share benchmark · not copied trader returns');ax.legend(fontsize=8);fig.autofmt_xdate();finish(fig,'paper_cumulative')
    z=pd.read_csv(OUT/'Cost_Delay_Sensitivity.csv');z=z[z['sample']=='all'];matrix=z.pivot(index='cost',columns='delay',values='return_on_aggregate_outlay')
    fig,ax=plt.subplots(figsize=(7.8,4.5));im=ax.imshow(matrix*100,cmap='RdYlBu',aspect='auto');ax.set_xticks(range(len(matrix.columns)),[str(x) for x in matrix.columns]);ax.set_yticks(range(len(matrix.index)),[f'${x:.3f}' for x in matrix.index]);
    for i in range(len(matrix)):
        for j in range(len(matrix.columns)):ax.text(j,i,f'{matrix.iloc[i,j]*100:.1f}%',ha='center',va='center',color='#192939',fontsize=9)
    ax.set(xlabel='Requested delay (seconds); actual snapshot delays differ',ylabel='Hypothetical extra cost / share',title='Conditional return on aggregate outlay · cohorts differ');fig.colorbar(im,ax=ax,label='Percent');finish(fig,'cost_delay')
    s=json.loads((OUT/'Synthetic_Selection_Summary.json').read_text())['summaries'];keys=['selected_train_win_rate','selected_validation_win_rate','selected_test_win_rate','forbidden_test_selected_win_rate'];v=[s[k]['mean'] for k in keys]
    fig,ax=plt.subplots(figsize=(7.8,4.4));ax.bar(['Training-selected:\ntraining','Training-selected:\nvalidation','Training-selected:\ntest','Forbidden test\nselection'],np.array(v)*100,color=['#4777ad','#097c71','#097c71','#b95162']);ax.axhline(50,color='#25364a',ls='--',label='Known true probability: 50%');ax.set(ylabel='Mean win rate (%)',ylim=(40,72),title='SYNTHETIC NULL · 1,000 unskilled participants / 250 worlds');ax.legend();finish(fig,'synthetic_selection')

def report():
    r=json.loads((OUT/'Results.json').read_text());categories=pd.read_csv(OUT/'Category_Metrics.csv')
    f=pd.read_csv(OUT/'Forecast_Metrics.csv');f=f[(f.split=='test')&(f.metric=='brier')]
    sens=pd.read_csv(OUT/'Cost_Delay_Sensitivity.csv');s=sens[(sens['sample']=='all')&(sens.cost==.01)]
    robust=json.loads((OUT/'Robustness.json').read_text());broad=next(x for x in robust if x['check']=='resample_whole_archive_chapters')
    def fmt(v):return 'unsupported' if v is None or (isinstance(v,float) and not np.isfinite(v)) else f'{v:.5f}'
    repl={
        'CLAIMS_TABLE':md_table(['Source','Claim','Available evidence','Assessment'],CLAIMS),
        'PLATFORM_TABLE':md_table(['Research feature','Polymarket','Kalshi','Verified scope'],PLATFORMS),
        'DATASET_TABLE':md_table(['Dataset','Coverage / records','Information / price type','Rights / reliability'],DATASETS),
        'CATEGORY_TABLE':md_table(['Category','Markets','Event groups','Brier','Accuracy','Mean spread'],
            [(x.category,int(x.markets),int(x.event_clusters),f'{x.brier:.5f}',f'{x.accuracy:.1%}',f'${x.mean_spread:.3f}') for x in categories.itertuples()]),
        'TEST_TABLE':md_table(['Forecast','Test markets','Brier','95% event-cluster interval'],
            [(x.model,int(x.markets),f'{x.estimate:.5f}',f'[{x.ci_low:.5f}, {x.ci_high:.5f}]') for x in f.itertuples()]),
        'EXPERIMENT_TABLE':md_table(['Experiment','Supported status','Interpretation'],EXPERIMENTS),
        'BIAS_TABLE':md_table(['Problem','How it can inflate apparent performance','Concrete evidence / control / limit'],BIAS),
        'DELAY_TABLE':md_table(['Requested delay','Modeled positions','Skipped markets','Median effective delay','Net P&L','Outlay return'],
            [(f'{int(x.delay)}s',int(x.filled),int(x.skipped),f'{x.median_effective_delay_seconds:.1f}s',f'${x.net_pnl:.2f}',f'{x.return_on_aggregate_outlay:.2%}') for x in s.itertuples()]),
        'CHAPTER_CI':f"[${broad['ci_low']:.5f}, ${broad['ci_high']:.5f}] per share across {broad['chapters']} eligible chapter blocks",
        'ROBUSTNESS_TABLE':md_table(['Diagnostic','Result','Interpretation'],[
            ('Training group fraction 50%','156 test markets; adjustment 0; market/adjusted Brier 0.21463.','Exploratory split sensitivity, no new untouched test.'),
            ('Training group fraction 60%','93 test markets; adjustment 0.5; scores 0.21924 / 0.22663.','Prespecified primary; no improvement established.'),
            ('Training group fraction 70%','42 test markets; adjustment 0; both scores 0.22436.','Very small test; no improvement established.'),
            ('Spread gate <=0.10','1,574 modeled positions; net −$47.12.','Conditional subset; narrower liquidity eligibility.'),
            ('Spread gate <=0.20','1,770 modeled positions; net −$62.65.','Primary hypothetical one-cent cost.'),
            ('Spread gate <=1.00','2,019 modeled positions; net −$150.19.','Wide-book positions increase modeled losses.'),
            ('Remove largest 1 / 5 / 10 positive contributions','Net −$63.63 / −$67.41 / −$71.85.','Negative benchmark not rescued by removing wins.'),
            ('Minimum prior category counts 5 / 20 / 50','Zero test observations with prior supported category.','Distribution shift exposed rather than hidden.'),
            ('Exclude p outside 0.05–0.95','1,818 markets; descriptive Brier 0.19570.','Full-sample diagnostic, not a new holdout.'),
            ('Synthetic training fractions 40–70%','Selection creates training advantage while average later wins stay near 50%.','Known zero-skill demonstration only.')]),
        'SOURCE_INDEX':'\n'.join(f"- [{x['id']}] {x['title']}. {x['url']} (accessed {x['access_date']})." for x in json.loads((OUT/'Source_Manifest.json').read_text()) if x['status']=='inspected'),
        'VALIDATION_TEXT':'The clean-data analysis, cashflow identities, temporal leakage controls and known metric values are checked by automated tests. The notebook is executed rather than supplied with invented outputs. Browser smoke tests check offline loading and control changes. Validation.json records final outcomes; no successful check is inferred merely from a file name. Excel summary numbers and formula references are reconciled independently in Python; formula cells are set to recalculate when opened, and an actual Excel calculation engine was not available here.'
    }
    text=(ROOT/'Report.template.md').read_text()
    for k,v in repl.items():text=text.replace('{{'+k+'}}',v)
    assert '{{' not in text
    (OUT/'Research_Report.md').write_text(text)
    (OUT/'Methodology.md').write_text((ROOT/'Methodology.template.md').read_text())
    pd.DataFrame(CLAIMS,columns=['source','claim','available_evidence','assessment']).to_csv(OUT/'Claim_Evidence.csv',index=False)
    pd.DataFrame(PLATFORMS,columns=['feature','polymarket','kalshi','verified_scope']).to_csv(OUT/'Platform_Comparison.csv',index=False)
    pd.DataFrame(DATASETS,columns=['dataset','coverage','information','rights_reliability']).to_csv(OUT/'Dataset_Catalog.csv',index=False)
    pd.DataFrame(EXPERIMENTS,columns=['experiment','status','interpretation']).to_csv(OUT/'Experiment_Support.csv',index=False)

def spreadsheet():
    wb=Workbook();wb.remove(wb.active)
    wb.calculation=CalcProperties(calcId=191029,fullCalcOnLoad=True,forceFullCalc=True)
    def sheet(name,d):
        ws=wb.create_sheet(name);ws.append(list(d.columns))
        for row in d.itertuples(index=False,name=None):
            values=[]
            for x in row:
                if pd.isna(x):values.append(None)
                elif isinstance(x,(np.integer,)):values.append(int(x))
                elif isinstance(x,(np.floating,)):values.append(float(x))
                else:values.append(x)
            ws.append(values)
        ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
        for c in ws[1]:c.fill=PatternFill('solid',fgColor='152E42');c.font=Font(color='FFFFFF',bold=True);c.alignment=Alignment(wrap_text=True)
        ws.row_dimensions[1].height=32
        for i,col in enumerate(d.columns,1):ws.column_dimensions[get_column_letter(i)].width=min(55,max(16,len(col)+3))
        return ws
    sheet('README',pd.DataFrame([
        ('Scope','HISTORICAL DATA / PAPER SIMULATION ONLY; no observed participant panel.'),
        ('Provenance','Marketlens CC BY 4.0; provider labels not independently settled; source commit in historical data.'),
        ('Unavailable','Actual trader profit, persistence, capital ROI, equity drawdown, and Kalshi numerical comparison.'),
        ('Net modeled P&L','One-share first-outcome conditional asks minus illustrative extra costs; not actual earned money.'),
        ('Formula handling','Primary_Paper formula columns recalculate on open. Adjacent numerical columns are already verified.'),
        ('Uncertainty','Event-cluster bootstrap conditional on selected archive; few independent category/time blocks.'),
        ('Sources','See Sources sheet and Sources.md for URLs, dates and inspected/blocked status.')],columns=['item','explanation']))
    r=json.loads((OUT/'Results.json').read_text());p=r['primary_paper_benchmark']
    sheet('Summary',pd.DataFrame([(k,json.dumps(v) if isinstance(v,(dict,list)) else v) for k,v in p.items()],columns=['metric','value']))
    files={'Forecast_Metrics':'Forecast_Metrics.csv','Categories':'Category_Metrics.csv','Paper_Categories':'Paper_Category_Metrics.csv',
           'Cost_Delay':'Cost_Delay_Sensitivity.csv','Historical_Data':'Historical_Data.csv','Quote_Observations':'Historical_Execution_Quotes.csv',
           'Paper_Skips':'Paper_Skips.csv','Splits':'Split_Summary.csv','Audit':'Data_Audit.csv','Exclusions':'Excluded_Observations.csv',
           'Synthetic_Worlds':'Synthetic_Selection_Replications.csv','Synthetic_Example':'Synthetic_Participant_Example.csv',
           'Claims':'Claim_Evidence.csv','Platforms':'Platform_Comparison.csv','Datasets':'Dataset_Catalog.csv','Dictionary':'Data_Dictionary.csv'}
    for name,filename in files.items():sheet(name,pd.read_csv(OUT/filename))
    paper=pd.read_csv(OUT/'Paper_Positions.csv')
    cols=['market_id','event_cluster','category','quantity','y','ask','modeled_cost','gross_pnl','net_pnl','outlay','return_on_outlay','ask_size','spread','quote_time','resolved_at']
    ws=sheet('Primary_Paper',paper[cols])
    for col,label in [(16,'formula_gross_pnl'),(17,'formula_net_pnl'),(18,'formula_outlay'),(19,'formula_return_on_outlay')]:ws.cell(1,col,label)
    for row in range(2,len(paper)+2):
        ws.cell(row,16,f'=D{row}*(E{row}-F{row})')
        ws.cell(row,17,f'=D{row}*E{row}-D{row}*F{row}-G{row}')
        ws.cell(row,18,f'=D{row}*F{row}+G{row}')
        ws.cell(row,19,f'=Q{row}/R{row}')
        for col in range(4,20):ws.cell(row,col).number_format='0.000000'
    ws.auto_filter.ref=ws.dimensions
    sheet('Sources',pd.DataFrame(json.loads((OUT/'Source_Manifest.json').read_text())))
    design=json.loads((ROOT/'Research_Design.json').read_text());sheet('Assumptions',pd.DataFrame([(k,json.dumps(v) if isinstance(v,(dict,list)) else v) for k,v in design.items()],columns=['setting','value']))
    sheet('Robustness',pd.DataFrame(json.loads((OUT/'Robustness.json').read_text())))
    sheet('Matched_Delay',pd.DataFrame(json.loads((OUT/'Matched_Delay_Comparisons.json').read_text())))
    wb.save(OUT/'Backtest_Analysis.xlsx')

def dashboard():
    d=pd.read_csv(OUT/'Forecast_Observations.csv');q=pd.read_csv(OUT/'Historical_Execution_Quotes.csv')
    q['split']=q.market_id.map(d.set_index('market_id').split)
    keep=['market_id','event_cluster','category','anchor_time','resolved_at','p_market','y','requested_delay_seconds',
          'execution_status','quote_time','effective_delay_seconds','additional_snapshot_wait_seconds','bid','ask','ask_size','midpoint','spread','split']
    dc=['market_id','event_cluster','category','anchor_time','resolved_at','p_market','y','anchor_spread','p_adjusted','split']
    rng=np.random.default_rng(20261014);wins=rng.integers(0,2,size=(1000,200),dtype=np.int8)
    data={'markets':d[dc].where(d[dc].notna(),None).to_dict('records'),
          'quotes':q[keep].where(q[keep].notna(),None).to_dict('records'),
          'results':json.loads((OUT/'Results.json').read_text()),
          'sensitivity':pd.read_csv(OUT/'Cost_Delay_Sensitivity.csv').to_dict('records'),
          'sources':json.loads((OUT/'Source_Manifest.json').read_text()),
          'syntheticBits':[''.join(str(v) for v in row) for row in wins]}
    payload=json.dumps(clean_json(data),separators=(',',':'),allow_nan=False).replace('</','<\\/')
    page=(ROOT/'Dashboard.template.html').read_text().replace('<!--PLOTLY_LIBRARY-->','<script>'+get_plotlyjs()+'</script>').replace('/*EMBEDDED_DATA*/','const DATA='+payload+';')
    (OUT/'Historical_Research_Dashboard.html').write_text(page)

def notebook():
    md=nbformat.v4.new_markdown_cell;code=nbformat.v4.new_code_cell
    nb=nbformat.v4.new_notebook(cells=[
        md('# Prediction Market Research Lab\n**Historical data / paper simulation only.**\n\nThis notebook computes market-reference diagnostics and a conditional one-share benchmark from supplied historical CSVs. It does not contain participant histories, connect to an account or call a live market API. Third-party settlements have not been officially corroborated. Synthetic selection results are separate.'),
        code("from pathlib import Path\nimport sys, json\nimport numpy as np\nimport pandas as pd\nimport matplotlib.pyplot as plt\nROOT = next(p for p in [Path.cwd(), Path.cwd().parent] if (p/'src/analysis.py').exists())\nsys.path.insert(0, str(ROOT/'src'))\nimport analysis\nd = analysis.assign_splits(analysis.read_data())\nassert len(d)==2021 and not d.market_id.duplicated().any()\nd.groupby(['split','category']).agg(markets=('market_id','size'), event_groups=('event_cluster','nunique'))"),
        md('## Data integrity and limits\nAll source-history hashes matched the provider manifest; this establishes archive integrity, not independent exchange verification. Outcomes use the first named contract side. The final holdout is esports only, with no unpurged training esports.'),
        code("audit=pd.read_csv(ROOT/'deliverables/Data_Audit.csv')\nassert int(audit.trade_rows.sum())==1120033\nassert int(audit.duplicate_trade_ids.sum())==0\nfor early,late in [('train','validation'),('validation','test')]:\n    a,b=d[d.split==early],d[d.split==late]\n    assert a.resolved_at.max()<b.anchor_time.min()\n    assert set(a.event_cluster).isdisjoint(b.event_cluster)\njson.loads((ROOT/'deliverables/Data_Summary.json').read_text())"),
        md('## Recompute primary holdout scores\nThe model choice was frozen using validation results before the initial test. Recomputing it here does not create another untouched holdout. Error intervals resample related-event groups.'),
        code("frozen=json.loads((ROOT/'deliverables/Selected_Model.json').read_text())\nt=d[d.split=='test'].copy()\np=(1-frozen['shrinkage'])*t.p_market+frozen['shrinkage']*.5\nrows=[]\nfor name,prob in [('market',t.p_market),('selected_adjustment',p),('constant_50',np.full(len(t),.5))]:\n    score=analysis.metric_values(t.y,prob)['brier']\n    rows.append({'forecast':name,**analysis.cluster_interval(t,score)})\nassert np.isclose(rows[0]['estimate'],0.21924017204301074)\npd.DataFrame(rows)"),
        code("z=pd.read_csv(ROOT/'deliverables/Calibration.csv')\nz=z[z.category=='All']\nfig,ax=plt.subplots(figsize=(7,4))\nax.plot([0,1],[0,1],'--',color='gray')\nax.plot(z.mean_probability,z.observed_frequency,'o-',color='teal')\nax.set(xlabel='Archived midpoint probability',ylabel='Provider-reported frequency',title='Market-reference calibration; no participant forecasts')\nplt.show()"),
        md('## Recompute conditional paper cashflows\nOne first-outcome share at eligible archived ask; illustrative extra cost $0.01/share. Posted depth does not establish an actual historical fill. These are not copied returns or capital ROI.'),
        code("q=pd.read_csv(ROOT/'deliverables/Historical_Execution_Quotes.csv')\nq['split']=q.market_id.map(d.set_index('market_id').split)\npaper,skips=analysis.simulate(q,cost=.01,delay=0)\nassert np.allclose(paper.net_pnl,paper.quantity*paper.y-paper.outlay)\nassert np.isclose(paper.net_pnl.sum(),-62.6495)\nsummary=analysis.simulation_summary(paper,skips,.01,0)\nsummary"),
        code("curve=paper.groupby('resolved_at')[['gross_pnl','net_pnl']].sum().sort_index().cumsum()\ncurve.index=pd.to_datetime(curve.index,utc=True)\nax=curve.plot(figsize=(8,4),title='Finalized conditional paper cashflows; not account equity')\nax.set_ylabel('USD modeled P&L')\nplt.show()"),
        md('## Synthetic selection, not platform users\nAll 1,000 participants have true success probability 0.5. The top 5% are selected using training only. An intentionally forbidden test-selected group illustrates hindsight bias.'),
        code("worlds,example,synthetic=analysis.synthetic_experiment()\nassert synthetic['true_skill']==0\nassert abs(worlds.selected_test_win_rate.mean()-.5)<.005\nworlds.drop(columns='repetition').agg(['mean','std'])"),
        md('## Automated checks and reproduction\nThe tests check known scores, cashflow reconciliation, input ordering, depth skips, label availability, duplicate records and isolation from test labels. See Methodology.md, Data_Dictionary.md and Sources.md for exact assumptions.'),
        code("import subprocess\nresult=subprocess.run([sys.executable,'-m','pytest',str(ROOT/'tests'),'-q'],cwd=ROOT,capture_output=True,text=True)\nprint(result.stdout)\nassert result.returncode==0, result.stderr\nprint('Offline research checks completed.')")
    ])
    nb.metadata.kernelspec={'name':'python3','display_name':'Python 3','language':'python'}
    nb.metadata.language_info={'name':'python','version':'3.12'}
    nbformat.write(nb,OUT/'Research_Notebook.ipynb')

def main():
    dictionary();charts();report();spreadsheet();dashboard();notebook()
    print('Created charts, report source, methodology, dictionary, spreadsheet, self-contained dashboard and notebook.')

if __name__=='__main__':main()
