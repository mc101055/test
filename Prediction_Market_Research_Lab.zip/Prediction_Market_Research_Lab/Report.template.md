# Prediction Market Research Lab

## Historical trader success, copying, and what public evidence can establish

**HISTORICAL DATA / PAPER SIMULATION ONLY**  
Research date: October 14, 2026.  
Platforms examined: Polymarket and Kalshi. Numerical dataset: a third-party Polymarket archive, June–September 2026.  
Primary conclusion: **real participant persistence and copied advantage remain unidentifiable in the acquired data.**

## 1. Executive summary

Publicly visible profits are a reason to investigate, not evidence that a follower has a repeatable advantage. Profits combine forecasting, capital, entry prices, inventory management, execution, exposure to rare outcomes, and selection of which participants to display. The important object is later, cost-adjusted follower performance for participants selected using information available at the time. It is not the current leaderboard or a leader’s final dollar profit.

This project delivers an actual offline research lab using 2,021 binary market records and archived quote/settlement metadata, with no invented trader histories. All 2,278 source-history file hashes and reported row counts matched the provider’s manifest; 1,120,033 trade records were audited for IDs, timestamps, prices and sizes. The source is Marketlens’s public, CC BY 4.0 archive [S01–S05]. Hash verification confirms that the downloaded files match that archive, not that every quoted record or settlement is independently authenticated. Official API access was blocked, so all empirical results are conditional on third-party reported records and labels.

The central participant question is **inconclusive**, for a specific reason: the acquired data contain no participant identifiers or longitudinal portfolios. Neither historical-winner persistence nor participant information beyond market prices can be tested. No Kalshi numerical dataset was acquired. The report does not claim that all successful traders are lucky, that no genuine skill exists, or that all copying results disappear under valid testing.

The supported results are more modest and useful:

- A synthetic population with **zero skill** produces selected participants with **59.33% training wins**, followed by **49.99% test wins**. Selecting winners after examining test results instead produces **66.21% test wins**. These are explicitly synthetic mathematical results, not Polymarket or Kalshi users.
- The final historical holdout has **93 markets in 35 esports event groups on one day**. Market midpoints have a Brier score of **0.21924**, compared with **0.25000** for a constant 50% forecast. The adjustment selected using validation data has **0.22663**, worse than the market benchmark, with no reliably measured improvement.
- A mechanical first-outcome paper benchmark models **1,770 one-share positions** at archived asks. Gross P&L is **−$44.95**; adding an explicitly hypothetical one-cent extra cost per share makes it **−$62.65**. Return on summed modeled outlay is **−9.81%**. These are not realized trader earnings, capital ROI, or a copied strategy.
- On those same positions, using non-executable midpoints instead of asks would show just **−$4.97**. The difference is **$39.98** from crossing half-spreads; the modeled additional cost is **$17.70**. Entry assumptions can therefore dominate apparent historical performance even without copying anyone.
- Delayed entry costs worsen on matched cohorts in this archive, but the quotes are sparse and effective delays exceed the requested delays. Those results describe selected quote pairs, not guaranteed fills or universal latency penalties.

The reviewed open-source copying material establishes that monitoring-and-mirroring software and paper simulations exist. It does not supply an independently audited, complete follower ledger with a predetermined selection rule and untouched evaluation period. The strongest defensible answer is: **past public success alone does not establish a repeatable copied edge; the evidence obtained here is insufficient to decide how much real trader success reflects skill rather than selection and execution.**

## 2. What online success stories actually show

### What “copy trading” means

At least four practices are mixed together: mirroring an observed fill later, imitating a displayed position, following a person’s narrative forecast, and executing a strategy inspired by another participant. They have different information sets. A fill is evidence that the original participant obtained an execution, not that the same price or remaining liquidity is available after observation. A position view mixes past entries and exits. A narrative can omit size, hedges and losing positions. Strategy replication may depend on infrastructure or research that a follower does not possess.

An inspected copying README describes monitoring every second, capital-scaled mirroring and trade aggregation, and displays dashboard images [S17]. These are descriptions of intended functionality. “Copy the best, automate success” and “executes instantly” are promotional language, not a controlled performance study. The README does not supply a complete dated follower cashflow ledger that can be reconciled here. A screenshot cannot establish deposits, cost basis, hidden losses, full entry history, or whether a winning wallet was chosen retrospectively.

Another toolkit says participants have “proved” alpha, while its hosted copying service explicitly operated as a paper beta, is closed, and never handled real funds [S18]. A paper demonstration can be technically useful, but it cannot be counted as independently verified earned profit. The same README lists copying, spread capture, market making and structural arbitrage as distinct mechanisms. That alone cautions against interpreting high dollar profits as pure forecasting ability.

### Claims inventory and verification status

{{CLAIMS_TABLE}}

The crash-recovery examples are **not copying evidence**. They are included because they illustrate how vendor strategy statistics can be mistaken for comparable, independently reproduced performance. One README reports 280 live trades and 80.4% wins; a related data README reports 302 and 79.8% [S20, S22]. These might reflect different updates or definitions; their summaries are not enough to reconcile them. Neither claim is treated as false merely because it was not verified, and neither is treated as verified simply because code is public. A high win rate alone omits loss severity, capital, costs, exposure and whether parameter choices used future results.

A research repository provides useful cautions about incomplete wallet histories, proxy price fills, lifecycle sizing and biased exit selection. It deliberately excludes public raw wallet histories, and notes that baseline comparison is outside its current scope [S19]. Its methodology is useful; an unrerun repository is not an independent performance replication.

### Coverage limits

Twenty-eight inspected source documents/search pages are cataloged, including platform-owned code, dataset manifests, research code and self-authored claims; additional discovery searches are logged separately. Broad search, Reddit, arXiv, official documentation sites and platform APIs returned proxy CONNECT 403 errors. No Reddit firsthand story was independently assessed, no screenshot-only earnings claim was certified, and no academic full text was read in this environment. Bibliographic leads discovered in a research README are separated in Sources.md from verified sources. This is a constrained evidence review, not an exhaustive review of every public success or failure. Absence of a verified copying case in the inspected set does not establish absence across the internet.

## 3. Polymarket versus Kalshi

The platforms offer different public research opportunities. The inspected historical Polymarket exchange documentation describes off-chain matching with on-chain settlement and conditional-token mint/merge operations [S06]. Public fill schemas include maker/taker roles and token amounts [S13]. That creates potential pseudonymous longitudinal linkage, but an address is not a verified person, and fills alone are not a complete portfolio accounting system.

The inspected Kalshi public trade schema contains trade ID, market, time, quantity, prices and taker side, with no participant IDs [S13]. The official starter client demonstrates signed authentication and a portfolio route [S09–S10]. This does not prove that every Kalshi resource is private, or that optional public profiles never exist. It does mean the anonymous tape examined here cannot independently link successive trades to a participant.

{{PLATFORM_TABLE}}

### Fees, spreads and historical versions

No effective-dated, official fee schedule was retrieved for the analyzed windows. Therefore this report does not assign a supposedly historical fee rate to either platform or assume fees stayed constant. The archived Polymarket contract documentation shows signed fee terms, proceeds-based charges and complementary-token symmetry [S06]; that describes contract mechanics, not the fee actually applied to a particular 2026 market. Current platform-owned repositories explicitly warn that older exchange/client versions are archived and direct users to replacements [S07–S08, S25]. A modern SDK or fee page cannot be substituted for a verified historical schedule.

Spreads are directly present in the downloaded Polymarket books. They vary substantially: the equity chapter has an average first-book spread near **0.972**, illustrating that a computed midpoint can be almost uninformative about executable entry. A separate vendor acknowledges mostly placeholder order books and no settlement labels in its own file [S20]. It would be invalid to treat those placeholders as robust executable prices or derive calibration by equating the last price with the true outcome.

For a future complete study, recover per-market fee effective dates, charged fill fees, rebates and incentive payments, network costs, and exact token/venue versions. Model order-size and funding constraints as well as quoted depth. This lab’s additional-cost grid is hypothetical and intentionally labeled as such.

## 4. Historical data findings

### Dataset inventory

{{DATASET_TABLE}}

The Marketlens archive contains selected recurring crypto windows, baseball, soccer, combat sports, esports, weather and one equity event. It is neither a random market sample nor an all-platform census. Every category appears in one provider-selected chapter; politics is absent. The numerical sample has no account identities, deposits, withdrawals, private positions, realized individual P&L or trader capital histories. Historical_Data.csv contains market-level rows; “anonymized observations” must not be misread as “anonymized traders.”

The complete provider event tape has 17,317,874 rows, including deltas, snapshots and trades. Only one first valid reference book per eligible market enters forecast scoring. The audit did not inflate the forecast sample to 17 million independent observations. Different contracts on the same match or weather observation share an outcome process, so they are grouped for resampling and time splitting.

### Cleaning and uncertainty

Of 2,278 markets, 120 overlapping crypto contracts, 108 markets without valid preclose books, and 29 with half/half or ambiguous settlement labels are excluded. The retained set has **2,021 markets in 171 event groups**. All exclusions are enumerated in Excluded_Observations.csv. Half-payout observations are not coded as losses, missing losses are not coded as zero, and post-resolution books are not used as forecasts.

The trade audit found no duplicate or missing IDs, out-of-range prices/invalid sizes, or unsorted raw tapes. Snapshot validation identified many empty sides and late books. This is why archived data must be checked before an attractive performance statistic is computed. Passing internal checks cannot independently authenticate the provider’s collection process or settlement labels. None of the 2,021 labels was verified by an official API in this session.

### Forecast quality

{{CATEGORY_TABLE}}

![Market-level calibration against provider-reported outcomes](charts/calibration.png)

The all-sample midpoint Brier score is **0.17846**, and threshold accuracy is **70.31%**. These are descriptive sample statistics, not trader skill measures. Many binary propositions have naturally low or high base rates; a high percentage of correct threshold calls can coexist with negative economic results. Categories differ in market subtype, time to resolution, event composition and quote width. The weather chapter’s low score cannot establish that weather offers a repeatable participant advantage: it contains only three event groups. One equity event cannot yield a useful category confidence interval.

A reliability diagram compares the average quoted probability with the observed first-outcome frequency in fixed bins. Its clustered intervals are conditional on the sample and are omitted where there is only one cluster. Different bins can draw on different categories and forecast horizons; the plot is not a universal calibration law for all Polymarket markets.

## 5. Do historical winners keep winning?

### Actual participants: unsupported

There is no observed participant panel in the acquired dataset. Consequently this project cannot estimate the percentage of profitable users, their profit concentration, their subsequent success rate, or persistence in actual forecasting accuracy. It would be incorrect to synthesize a list of “top traders,” assign archived trades to invented users, or infer a participant portfolio from anonymous Kalshi prints.

An adequate participant study would need a cohort defined before the observation window, complete linked fills and position/cash accounting, known label availability, non-survivors, resolved and open positions, and enough independent events in later periods. Participant selection must use only earlier information. Statistical uncertainty should account for repeated positions, shared events and participant heterogeneity; a large wallet with many fills on one election is not thousands of independent skill trials.

On-chain reconstructability is potential, not completion. Token-ID mapping, block times, transfers, splits, merges, redemptions, incentives, account aggregation and external hedges matter [S06, S13]. A high realized dollar total can reflect large risk exposure or spread capture. Return on turnover is not return on capital, and short-term mark-to-market profit is not settled cash profit.

### A genuine separated forecast evaluation, with narrow scope

The archived market-level experiment orders event groups by forecast time, splits 60/20/20 by groups, and purges any prior-period event unresolved at the next period’s start. It retains 1,765 training, 83 validation and 93 test markets; 80 markets are purged from model development/evaluation but retained in descriptive files. Related events do not cross periods. Validation chooses among three prespecified shrinkages toward 50%, then freezes the choice before testing.

{{TEST_TABLE}}

![Primary held-out forecast comparisons](charts/holdout_brier.png)

The selected adjustment’s improvement relative to market Brier is **−0.00739**, with a 95% event-cluster interval of **[−0.02055, +0.00565]**. It does not establish an improvement. The exploratory Holm-adjusted sign-flip p-value is **0.247** under its symmetry/independence assumptions. Market prices outperform a constant 50% benchmark in this small test, with an adjusted p-value near **0.049**, but that is conditional evidence about market forecasts, not copying.

The final holdout is entirely esports from a single day. There are no esports observations in the unpurged training period. A category-support requirement correctly finds **zero** comparable test observations. Alternative time splits choose different adjustments and provide only 42–156 test markets. This is a weak basis for cross-category generalization; the report does not hide the problem by silently selecting a more favorable split.

## 6. Offline historical and synthetic experiments

{{EXPERIMENT_TABLE}}

### The historical quote-taking benchmark

This is a fixed accounting benchmark: one share of the first named outcome at a valid archived ask, held to provider-reported settlement. It does not follow any trader. It rejects books with insufficient best-level size, excessive spread or invalid timing. A displayed quote is not proof that an actual order would have filled; queue dynamics, minimum-dollar rules, stale quotes and exchange routing are unavailable. The results are conditional on assumed execution at that snapshot.

Gross P&L is payout minus ask. Extra modeled cost is subtracted separately; the spread is already paid in the ask. With one-cent extra cost, 1,770 modeled positions lose **$62.65** on **$638.65** summed outlay, with **32.49%** positive modeled outcomes. Median position return on outlay is **−100%**, reflecting binary losses, not a participant’s portfolio return. The final test subset has 83 modeled positions and net P&L **−$0.87**; its mean-P&L interval crosses zero widely.

The full-sample event-cluster interval for mean net P&L per share is approximately **[−$0.06760, −$0.00201]**. Exploratory resampling of entire provider chapters yields **{{CHAPTER_CI}}**. Few chapter blocks, provider selection and uncorroborated settlement labels prevent a strong population-level profitability claim. The negative aggregate benchmark does not show that copying a genuinely informed participant would be negative.

![Conditional paper cashflows in settlement order](charts/paper_cumulative.png)

The curve plots finalized position cashflows, not marked-to-market portfolio equity. Its maximum decline is **$73.98** in cumulative settled P&L; this is **not** maximum account equity drawdown. Capital ROI, Sharpe ratio, annualized returns and true participant drawdowns are not invented.

### Entry and observation delay

For the same anchor positions, midpoint accounting gives **−$4.97**, crossing the ask changes that to **−$44.95**, and one-cent additional cost changes it to **−$62.65**. This is a direct cashflow reconciliation, not a fitted strategy improvement. A leader who posted liquidity could receive different terms from a later follower taking liquidity; the archive does not contain the leader’s actual profit to compare with.

{{DELAY_TABLE}}

Requested 30-second entries have a median effective delay near **95 seconds**, because full recorded books are sparse. Matching only markets eligible at both times, the 30-second request decreases modeled P&L by about **$0.00350 per share**; the 300-second request by **$0.01412**. Entire delayed cohorts contain fewer markets, so their aggregate losses are not directly comparable to the anchor’s total. Matched intervals and actual wait times are supplied in separate files. No penalty is extrapolated to every participant, category or execution system.

![Cost and delay sensitivity of the conditional benchmark](charts/cost_delay.png)

### Synthetic winner selection

In each of 250 synthetic worlds, 1,000 equally unskilled participants make 200 independent fair binary trials. The first 120 are training, next 40 validation, last 40 test. Select 50 participants using training performance only. Their average win rate is **59.33%** in training, **49.95%** in validation and **49.99%** in test; the entire test population averages **49.99%**. The selected group’s test win-rate range across simulated worlds is roughly **47.85–52.23%** for the central 95% of worlds. That is a simulation distribution, not an interval for real traders.

A forbidden selector that ranks on test outcomes instead attains **66.21%** average test wins. It appears substantially superior even though every participant’s true success probability is exactly 50%. This supplies a concrete demonstration of hindsight selection. It does not estimate the share of actual platform profits due to luck.

![Synthetic zero-skill winner selection; no observed platform users](charts/synthetic_selection.png)

The dashboard labels synthetic distributions and allows offline changes in training fraction and minimum sample size. These controls change an illustrative simulated world, not live signals. Synthetic profit concentration is not substituted for unavailable observed trader concentration.

## 7. Why seemingly profitable methods can fail

Each distortion has a different remedy. Merely reporting more decimal places or increasing the number of fills does not solve them.

{{BIAS_TABLE}}

The inspection supplies concrete examples of several problems: paper funds described as a hosted service [S18]; price archives without resolution labels and with placeholder books [S20]; copy-research tooling explicitly warning about proxy fills, lifecycle look-ahead and biased exit rules [S19]; and an actual $39.98 difference between midpoint and ask accounting in the paper benchmark. The audit also encountered 29 half/half settlements that cannot safely be forced into a binary success label. Where a problem is conceptual rather than a documented historical episode, the table says so rather than inventing a failure story.

Public demonstrations are selected publications. This review does not measure how often failures are excluded because it lacks a denominator of all attempts. A creator can truthfully show a winning interval and still provide a misleading estimate of general performance. A fair replication must identify the selection rule, time it was fixed, complete cohort, exact information delays, realistic prices and liquidity, all costs, and unsuccessful as well as successful cases.

## 8. Statistical confidence and robustness

Confidence is strongest for reproducible arithmetic within the provided files: hash and record reconciliation, timestamp separation, loss calculations and synthetic null outcomes. It is weaker for the historical archive’s external authenticity because official settlement checks were blocked. It is weaker still for platform-wide inference because the sample is provider-selected and categories have limited independent events. Actual trader persistence and copying are unsupported rather than merely statistically insignificant.

The paired forecast intervals resample entire event groups and preserve market-level loss differences. An ordinary binomial test treating millions of contracts as independent could grossly overstate precision. Research code inspected elsewhere sometimes counts contract-weighted successes in significance calculations [S16]; contract count by itself does not establish independent sampling. This report instead uses clustered uncertainty and makes the remaining common-shock limitation explicit.

{{ROBUSTNESS_TABLE}}

Spread restrictions of 0.10, 0.20 and 1.00 yield negative full-sample benchmark net totals. Removing the one, five or ten largest positive contributions makes the negative total larger; it does not reveal an apparent positive result dependent on a single winner. Excluding extreme midpoint probabilities raises the descriptive Brier score to **0.19570**, illustrating easier observations’ influence. None of these sensitivities turns the benchmark into an estimate of actual copying advantage. Alternative splits and dashboard filters are exploratory after the primary holdout; they are not new confirmatory evidence.

The exploratory significance tests adjust three prespecified forecast comparisons with Holm’s procedure. That does not correct every possible model, threshold, archive choice or public success story. Effect size, uncertainty, independent event count and data relevance remain more useful than a p-value alone.

## 9. Research limitations and unfinished evidence

1. **No observed participant panel.** Profit distribution, winners’ persistence, actual follower returns, concentration and capital ROI cannot be computed.
2. **No acquired Kalshi numerical dataset.** The platform comparison concerns inspected interfaces and schemas, not measured relative profitability.
3. **No independent official settlement validation.** All historical metrics depend on the third-party labels being correct.
4. **Restricted research coverage.** Reddit, broad search, academic full texts, official documentation and platform APIs were blocked. Source leads are recorded, not represented as read.
5. **Selected, short event windows.** There are seven provider-selected chapters, one per category, and only one-day esports in the primary holdout.
6. **Heterogeneous forecast horizons.** First captured valid books can be in-play or far from market creation; category comparisons are not time-matched.
7. **Conditional execution.** Recorded price/depth does not establish a fill, exchange minimum-order compliance, liquidity persistence or passive queue position.
8. **Hypothetical additional costs.** Historical fees, rebates and gas effective dates are not reconstructed; cost scenarios are not platform fee claims.
9. **Missing portfolios and hedges.** Cashflows for the artificial buy-and-hold unit do not reconstruct a real trader’s complete economic result.
10. **Dependence and repeated investigation.** Event clustering reduces duplication but cannot fully remove day-wide shocks or publication/researcher selection.

To complete the unanswered participant study, acquire permitted archived anonymized panels with audited cashflow/position coverage, verify official settlement and fee histories, and define a cohort/selection rule prospectively with respect to the historical timeline. Preserve failures and inactive users. Use later independent event blocks, matched follower execution, and genuine holdout evaluation. Do not expose a directory of current wallets or turn the research into an execution system.

The saved environment draft adds the blocked research domains. To extend this review, the user must review and save those changes in environment settings, then publish the environment and recheck access. Draft persistence does not apply the policy or establish successful access. The existing offline lab runs without that action, accounts or API secrets.

## 10. Final conclusion

**Selecting historically profitable prediction-market participants does not, by itself, provide credible evidence of repeatable predictive skill or a repeatable copying advantage.** It conditions on success while leaving execution, exposure, hidden positions and selection unresolved. A complete time-separated participant study could establish skill, but one was not identifiable from the acquired records.

The strongest positive finding here is that archived market prices contain useful predictive information relative to an uninformative 50% benchmark in a narrow held-out sample. The strongest cautionary findings are the synthetic disappearance of apparent past skill under independent testing, the sizeable midpoint-to-ask accounting difference, negative quote-taking benchmark outcomes after explicit hypothetical costs, and the fragility of cross-category evaluation. **None of these proves that real successful traders are predominantly lucky, or that all copying performance vanishes.** Those proportions and causal claims remain unmeasured.

The appropriate conclusion is mixed and constrained: demonstrated market information, clear mechanical selection/execution hazards, and insufficient evidence about real trader persistence. The deliverables make those distinctions visible and reproducible instead of manufacturing an exciting result.

## Deliverables, verification and references

Research_Report.pdf is this report. Historical_Research_Dashboard.html embeds its historical data and plotting library and reruns locally. Backtest_Analysis.xlsx contains numerical summaries, underlying rows, documented scenarios, exclusion records and cashflow formulas. Research_Notebook.ipynb is an executed notebook. Historical_Data.csv contains 2,021 third-party reported historical market records, with no participant identifiers or synthetic users. Methodology.md, Data_Dictionary.md and Sources.md describe the precise design and source limitations. Supporting CSV/JSON files expose all modeled positions, skips, categories, splits, uncertainty and synthetic repetitions. The full lab includes source code, tests and hash-pinned dependencies.

{{VALIDATION_TEXT}}

### Citation index

{{SOURCE_INDEX}}

See Sources.md for every URL, access date, content hash, evidence classification, blocked request and bibliographic lead. Source IDs refer to inspected documents unless explicitly marked blocked. The report cites no uninspected paper’s numerical findings.
